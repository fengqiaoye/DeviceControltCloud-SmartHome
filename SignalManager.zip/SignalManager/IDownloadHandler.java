package LogicLayer.SignalManager;

/**
 * Created by RyanLee on 2015/4/3.
 */
public interface IDownloadHandler {
    abstract void handleDownloadStatus( DownloadInfo downloadInfo);
}
