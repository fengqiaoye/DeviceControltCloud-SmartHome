package LogicLayer.SignalManager;

/**
 * Created by XWH on 2015/5/25.
 * 遥控发射信号
 */
public class SignalInfo {
    public int roomId;
    public int modelType;
    public String modelId;    // 遥控模板ID
    public int keyType;
    public int keyValue;
    public boolean simpleSignal = true;        // 是否是单一信号，（冰箱是复合信号）


    public SignalInfo(int roomId, int modelType, String modelId, int keyType, int keyValue, boolean simpleSignal){
        this.roomId = roomId;
        this.modelType = modelType;
        this.modelId = modelId;
        this.keyType = keyType;
        this.simpleSignal = simpleSignal;
        this.keyValue = keyValue;
    }
}
