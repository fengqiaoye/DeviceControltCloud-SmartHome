package LogicLayer.SignalManager;

/**
 * Created by RyanLee on 2015/4/3.
 */
public class DownloadInfo {
    String url;
    String modelID;
    int modelType;
    String filePath;
    String saveDir;
    IDownloadHandler handler;
    int status;
}