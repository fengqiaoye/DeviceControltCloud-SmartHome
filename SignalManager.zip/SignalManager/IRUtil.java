package LogicLayer.SignalManager;

import android.util.ArrayMap;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import Communication.Util.BytesUtil;
import Communication.log.Logger;
import LogicLayer.KeyDef;
import LogicLayer.SignalManager.IrDB.AirKeysInfo;
import LogicLayer.SignalManager.IrDB.MatchIRBytesInfo;
import LogicLayer.SignalManager.IrDB.MatchInfo;
import LogicLayer.SignalManager.IrDB.SignalDBOprator;

/**
 * Created by RyanLee on 2015/4/3.
 */
public class IRUtil {
    static public void main(String[] args) {
        byte[] data = {0x22, (byte) 0xd6};
        String[] data1 = {"22","d6"};
        long d1 = (long)data[0]<<8 & 0x00ff00;
        long d2 = data[1] & 0x00ff;
        long d3 = d1 | d2;
        long  hs = ((long)data[0]<<8 & 0x00ff00 ) | data[1] & 0x00ff;
        long  hs2 = ((long)data[1]<<8 & 0x00ff00 ) | data[0] & 0x00ff;

        String temp = data1[0] + data1[1];
        long hs1 = Long.parseLong(data1[0] + data1[1],16);

        try {
            String src = "格力abc123";

            byte[] dstByte1 = src.getBytes("utf-8");
            byte[] dstByte2 = src.getBytes("unicode");
            byte[] dstByte3 = src.getBytes("gb2312");

            String dstStr1 = new String(dstByte1, "utf-8");
            String dstStr2 = new String(dstByte1, "unicode");
            String dstStr3 = new String(dstByte1, "gb2312");

            String dstStr4 = new String(dstByte2, "utf-8");
            String dstStr5 = new String(dstByte2, "unicode");
            String dstStr6 = new String(dstByte2, "gb2312");

            String dstStr7 = new String(dstByte3, "utf-8");
            String dstStr8 = new String(dstByte3, "unicode");
            String dstStr9 = new String(dstByte3, "gb2312");

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(src);
            String str = stringBuilder.toString();

            int a = 1;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        File file = new File("e://格力6-020.txt");//new String(filePath.getBytes("UTF-8"), "GB2312"));
        boolean exist = file.exists();
        try {
            //FileOutputStream fis = new FileOutputStream(file);
            FileInputStream fos = new FileInputStream(file);

            int nSize = (int) file.length();
            byte[] buff = new byte[nSize];
            int nReadSize = fos.read(buff, 0, nSize);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
    public static long[] getIRString(byte[] rawdata){
        long[] waves = new long[1000];
        int index = 0;

        long fcarr=(rawdata[6] - 18)*1000;
        waves[index] = fcarr;
        index++;

        int cnt = 15;
        byte aByte = rawdata[15];
        while(aByte!=0) {
            long hs;
            boolean isError = false;
            switch(aByte){
                case (byte) 0xc1:
                    hs = ((long)rawdata[cnt + 1]<<8 & 0x00ff00 ) | rawdata[cnt + 2] & 0x00ff;
                    waves[index] = hs;
                    index++;
                    cnt += 3;
                    break;
                case (byte) 0xc2:
                    hs = (((long)rawdata[cnt + 1]<<16 & 0x00ff0000) | (rawdata[cnt + 2]<<8 & 0x00ff00) | rawdata[cnt + 3] & 0x00ff);
                    waves[index] = hs;
                    index++;
                    cnt += 4;
                    break;
                case (byte) 0xc3:
                    long bits = ((long)rawdata[cnt + 1]<<8  & 0x00ff00) | rawdata[cnt + 2] & 0x00ff;
                    int bitt;
                    for(int i= 0; i< bits; i++){
                        int bytet = i/8;
                        if(i%8 == 0){
                            //bytet = bytet + 1;
                        }
                        if((rawdata[5] & 0x0f) == 0){
                            bitt = i%8;
                        }else{
                            bitt = ~((i%8)&7);
                        }

                        if((rawdata[cnt+3 + bytet] & (0x01 << bitt)) == 0){
                            hs = (rawdata[7] & 127) << 8 | rawdata[8] & 0x00ff;
                            waves[index] = hs;
                            index++;
                            hs = (rawdata[9]<<8) | rawdata[10] & 0x00ff;
                            waves[index] = hs;
                            index++;
                        }else{
                            hs = (rawdata[11] & 127) << 8 | rawdata[12] & 0x00ff;
                            waves[index] = hs;
                            index++;
                            hs = (rawdata[13]<<8) | rawdata[14] & 0x00ff;
                            waves[index] = hs;
                            index++;
                        }
                    }

                    if((rawdata[5] & 240) == 0){
                        hs = (rawdata[7] & 127) << 8 | rawdata[8] & 0x00ff;
                        waves[index] = hs;
                        index++;
                    }

                    long bytes = bits/8;

                    if(bits%8 != 0){
                        bytes += 1;
                    }

                    cnt += bytes+3;
                    break;
                default:
                    Logger.d("abc", "数据错误");
                    isError = true;
                    break;
            }
            if (isError) {
                break;
            }
            aByte = rawdata[cnt];
        }


        //Logger.d("abc","17b6 = " + Long.parseLong(modulea[16] + modulea[18],16));
        /*float fcycle = (float)1000/(rawdata[6]-18);
        Logger.d("abc","fcycle = " + fcycle);
        String wvs="";

        for (Long aWave : waves) {
            Logger.d("abc", "wavesa[i] = " + aWave);
            Logger.d("abc", "Long.parseLong(wavesa[i],10) = " + aWave);
            Logger.d("abc", "Long.parseLong(wavesa[i],10)/fcycle = " + Math.round(aWave / fcycle));

            wvs += Math.round(aWave/fcycle) + ",";
        }

        String makewave = fcarr + "," + wvs + "10";*/
        //String makewave = fcarr + "," + waves;
       // Logger.d("Ryan","makewave =" + makewave);
        long[] retWaves = new long[index];
        System.arraycopy(waves, 0, retWaves, 0, index);
        return retWaves;
    }
    //万能码库格式转成Comsumer IR 格式
    public static String getIRString(String rawdata){
        String[] modulea = rawdata.split(",");
        String waves = "";
        int cnt = 15;
        String chr  = modulea[cnt];

        while(!chr.equals("0")){
            long hs;
            switch(chr){
                case "C1":
                    hs = Long.parseLong(modulea[cnt + 1] + modulea[cnt + 2],16);
                    waves += hs + ",";
                    cnt += 3;
                    break;
                case "C2":
                    hs = Long.parseLong(modulea[cnt + 1] + modulea[cnt + 2] + modulea[cnt + 3],16);
                    waves += hs + ",";
                    cnt += 4;
                    break;
                case "C3":
                    long bits = Long.parseLong(modulea[cnt + 1] + modulea[cnt + 2],16);
                    int bitt;
                    for(int i= 0; i< bits; i++){
                        int bytet = i/8;
                        if(i%8 == 0){
                            //bytet = bytet + 1;
                        }
                        if((Long.parseLong(modulea[5],16) & 0x0f) == 0){
                            bitt = i%8;
                        }else{
                            bitt = ~((i%8)&7);
                        }

                        if((Long.parseLong(modulea[cnt+3 + bytet],16) & (0x01 << bitt)) == 0){
                            hs = (Long.parseLong(modulea[7],16) & 127)*256 + Long.parseLong(modulea[8],16);
                            waves +=   hs + ",";
                            hs = Long.parseLong(modulea[9] + modulea[10],16);
                            waves += hs + ",";
                        }else{
                            hs = (Long.parseLong(modulea[11],16) & 127)*256 + Long.parseLong(modulea[12],16);
                            waves +=   hs + ",";
                            hs = Long.parseLong(modulea[13] + modulea[14],16);
                            waves += hs + ",";
                        }
                    }

                    if((Long.parseLong(modulea[5],16) & 240) == 0){
                        hs = (Long.parseLong(modulea[7],16) & 127) * 256 + Long.parseLong(modulea[8],16);
                        waves += hs + ",";
                    }

                    long bytes = bits/8;

                    if(bits%8 != 0){
                        bytes += 1;
                    }

                    cnt += bytes+3;
                    break;
                default:
                    Logger.d("abc", "数据错误");
                    break;
            }
            chr = modulea[cnt];
        }

        long fcarr=(Long.parseLong(modulea[6],16) - 18)*1000;
        Logger.d("abc","17b6 = " + Long.parseLong(modulea[16] + modulea[18],16));
        float fcycle = (float)1000/(Long.parseLong(modulea[6],16)-18);
        Logger.d("abc","fcycle = " + fcycle);
        /*String[] wavesa = waves.split(",");
        String wvs="";

        for(int i=0; i< wavesa.length; i++ ){
            Logger.d("abc", "wavesa[i] = " + wavesa[i]);
            Logger.d("abc", "Long.parseLong(wavesa[i],10) = " + Long.parseLong(wavesa[i],10));
            Logger.d("abc", "Long.parseLong(wavesa[i],10)/fcycle = " + Math.round(Long.parseLong(wavesa[i], 10) / fcycle));
            wvs += Math.round(Long.parseLong(wavesa[i],10)/fcycle) + ",";
        }
        String makewave = fcarr + "," + wvs + "10";*/
        String makewave = fcarr + "," + waves;
        Logger.d("Ryan","makewave =" + makewave);
        return makewave;
    }

    public static List<MatchInfo> getID(long[] dumps, SignalDBOprator dbOprator){
        TreeMap<Integer, List<MatchInfo> > matchInfoMap = new TreeMap<Integer, List<MatchInfo> >(new Comparator<Integer>() {
            public int compare(Integer d1, Integer d2) {
                return d2.compareTo(d1);
            }
        });

        MatchIRBytesInfo[] rds = dbOprator.getAllMachesBytes();
        //String[][] rds1 = dbOprator.getAllMaches();

        for(int i=0; i<rds.length; i++){
            byte[] mobsaByte = rds[i].matchBytes;
            long[]  mobsa = new long[mobsaByte.length];
            for (int k=0; k<mobsaByte.length; ++k) {
                mobsa[k] = ((long)mobsaByte[k])&0x000000ff;
            }

            int score = 0;
            if(mobsa[32]==dumps[32] && mobsa[33] == dumps[33]){
                score  += 600;
            }

            for(int k =0; k< 15; k++){
                int samp = (int) ((dumps[k*2]<<8) + dumps[k*2 +1]);
                int samp1 = (int) ((mobsa[k*2]<<8) + mobsa[k*2 +1]);

                if(samp + samp1 == 0){
                    score += 100;
                    break;
                }else{
                    if(samp != 0 && samp1 != 0){
                        float tp = (float)samp /samp1;

                        if(tp > 1){
                            tp = 1/tp;
                        }
                        if(tp > 0.6){
                            score += 50;
                        }
                    }
                }
            }

            int lens = (int) ((dumps[32]<<8) + dumps[33]);
            int lens1 = (int) ((mobsa[32]<<8) + mobsa[33]);

            if(lens > lens1){
                lens = lens1;
            }

            int kcnt = 1;
            int k = 1;

            do{
                if((dumps[k]>>4) ==mobsa[k]>>4 ){
                    score += 20;
                }

                if(dumps[k] == mobsa[k]){
                    score += 20;
                }
                k += 1;
                kcnt += 2;
            }while(lens > kcnt);

            MatchInfo matchInfo = new MatchInfo(score, rds[i].id, rds[i].name);
            List<MatchInfo> infos = matchInfoMap.get(score);
            if (null == infos) {
                infos = new ArrayList<MatchInfo>();
                infos.add(matchInfo);
                matchInfoMap.put(score, infos);
            }
            else {
                infos.add(matchInfo);
            }
        }


       List<MatchInfo> format = new ArrayList<MatchInfo>();

        int nCount = 0;
        int nIndex = 0;
        Iterator<Map.Entry<Integer,List<MatchInfo>>> itr = matchInfoMap.entrySet().iterator();
        for(; itr.hasNext();)
        {
            Map.Entry<Integer,List<MatchInfo>> mentry = itr.next();
            List<MatchInfo> matchInfos = mentry.getValue();
            for (MatchInfo matchInfoa:matchInfos) {
                if (nCount>=5 && nIndex>0) {
                    return format;
                }
                format.add(matchInfoa);
                nCount++;
            }

            nIndex++;
        }

        return format;
    }
    //智能匹配java源程序
    /*public static List<String[]> getID(String dumps, SignalDBOprator dbOprator){
        String[][] t_score = new String[500][3];
        String[] dump = dumps.split(",");
        String[][] rds;

        for(int i = 0; i< dump.length; i++){
            dump[i] = Integer.toString(Integer.parseInt(dump[i],16));
        }

        rds = dbOprator.getAllMaches();
        int rcnt = rds.length;

        for(int i=0; i<rds.length; i++){
            String[] mobsa = rds[i][1].split(",");

            for(int j=0; j< mobsa.length; j++){
                mobsa[j] = Integer.toString(Integer.parseInt(mobsa[j],16));
            }

            int score = 0;
            if(mobsa[32].equals(dump[32]) && mobsa[33].equals(dump[33])){
                score  += 600;
            }

            for(int k =0; k< 15; k++){
                int samp = Integer.parseInt(dump[k*2])*256 + Integer.parseInt(dump[k*2 +1]);
                int samp1 = Integer.parseInt(mobsa[k*2])*256 + Integer.parseInt(mobsa[k*2 +1]);

                if(samp + samp1 == 0){
                    score += 100;
                    break;
                }else{
                    if(samp != 0 && samp1 != 0){
                        float tp = (float)samp /samp1;

                        if(tp > 1){
                            tp = 1/tp;
                        }
                        if(tp > 0.6){
                            score += 50;
                        }
                    }
                }
            }

            int lens = Integer.parseInt(dump[32])*256 + Integer.parseInt(dump[33]);
            int lens1 = Integer.parseInt(mobsa[32])*256 + Integer.parseInt(mobsa[33]);

            if(lens > lens1){
                lens = lens1;
            }

            int kcnt = 1;
            int k = 1;

            do{
                if(Integer.parseInt(dump[k])/16 ==Integer.parseInt(mobsa[k])/16 ){
                    score += 20;
                }

                if(Integer.parseInt(dump[k])%16 ==Integer.parseInt(mobsa[k])%16){
                    score += 20;
                }
                k += 1;
                kcnt += 2;
            }while(lens > kcnt);

            t_score[i][0] = String.valueOf(score);  //分数
            t_score[i][1] = rds[i][0];
            t_score[i][2] = rds[i][2];

        }

        for(int i=0; i< rcnt; i++){
            for(int j=i+1; j< rcnt; j++){
                if(Integer.parseInt(t_score[i][0]) < Integer.parseInt(t_score[j][0])){
                    String tmp = t_score[i][0];
                    String tmp1 = t_score[i][1];
                    String tmp2 = t_score[i][2];

                    t_score[i][0] = t_score[j][0];
                    t_score[i][1] = t_score[j][1];
                    t_score[i][2] = t_score[j][2];

                    t_score[j][0] = tmp;
                    t_score[j][1] = tmp1;
                    t_score[j][2] = tmp2;
                }
            }
        }

        List<String[]> format= new ArrayList<String[]>();
        format.add( t_score[0]);
        format.add( t_score[1]);
        format.add( t_score[2]);
        format.add( t_score[3]);
        format.add( t_score[4]);

        return format;
    }*/

    public static String encode(long[] wavas, boolean isUper) {
        long[] matchWave = encode(wavas);
        return IRUtil.longToString(matchWave, isUper);
    }

    public static long[] encode(long[] wavas){
        long[] dump = new long[512];
        long[] machd = new long[512];

        for(int i=0; i<dump.length; i++){
            dump[i] = (long)0;
        }

        for(int i=1; i< wavas.length; i++){
            wavas[i] =  Math.round(wavas[i]/100.0);
        }

        for(int i=1; i< wavas.length-1; i++){
            for(int j=i+1; j < wavas.length; j++){
                float brt = (float)wavas[i] / wavas[j];
                //Logger.info("brt = " + brt);

                if(brt > 1){
                    brt = 1/brt;
                }

                //Logger.info("brt2 = " + brt);
                if(brt > 0.6){
                    wavas[j] = wavas[i];
                }
            }

        }

        int cnt = 0;

        for(int i=1; i < wavas.length; i++){
            long samples = wavas[i];
            int finds = 0;
            for(int j=0; j<cnt; j++){
                if(samples == dump[j]){
                    finds = 1;
                    break;
                }
            }

            if(finds == 0){
                dump[cnt] = samples;
                //Logger.info("dump[" + cnt + "] = " + dump[cnt]);
                cnt++;
            }
        }
        cnt--;

        if(cnt >32){
            Logger.i("Ryan","sample > 32.");
        }
        //Logger.info("cnt = " + cnt);
        for(int i=0; i<= cnt-1; i++){
            for(int j= i+1; j<= cnt; j++){
                if(dump[i] > dump[j]){
                    long tmp = dump[i];
                    dump[i] = dump[j];
                    dump[j] = tmp;
                }
            }
        }

        String bitstring = "";
        for(int i=1; i< wavas.length; i++){
            long samples = wavas[i];
            int j = 0;
            for(j=0; j<= cnt; j++){
                if(samples == dump[j]){
                    bitstring += (j+1) + ",";
                    break;
                }
            }

            if(j == cnt+1){
                Logger.i("Ryan","No Samples.");
            }
        }

        int bcnt = 0;
        for(int i = 0; i<16; i++ ){
            long samps = dump[i];

            machd[bcnt] = samps >> 8;
            machd[bcnt + 1] = samps & 0x00FF;
            bcnt += 2;
        }

        String[] bita = bitstring.split(",");
        int bits = bita.length;

        machd[bcnt] = bits >> 8;
        machd[bcnt + 1] = bits & 0x00FF;
        bcnt += 2;
        for(int i = 0; i< bits-1;){
            machd[bcnt] = (long)(Integer.parseInt(bita[i]) << 4) | Integer.parseInt(bita[i+1]) & 0x000f;
//            if("".equals(machd[bcnt])){
//                break;
//            }
            bcnt++;
            i += 2;
        }

        long[] retMachd = new long[bcnt];
        System.arraycopy(machd, 0, retMachd, 0, bcnt);
        return retMachd;

//        String rets = "";
//        for(int i= 1; i< machd.length; i++){
//            if("null".equals(machd[i])){
//                break;
//            }
//            rets += machd[i] + ",";
//        }
//        // Logger.info("rets = " + rets);
//        String ret= rets.replaceAll("null,", "");
//        return ret;
    }

    /** Comsumer IR格式转成适合匹配的 */
    public static String encode(String wavas){
        String[] dump = new String[512];
        String[] machd = new String[512];
        float fcycle;
        String[] wava = wavas.split(",");

        for(int i=0; i<dump.length; i++){
            dump[i] = "0";
        }

        fcycle =  Math.round((float)1000000*1.0/Integer.parseInt(wava[0],10));
        //Logger.info("fcycle = " + fcycle + ", wava[0] = " + wava[0]);
        for(int i=1; i< wava.length; i++){
            // 2015-04-03 周先生 更改
            //wava[i] = Integer.toString(Math.round(Integer.parseInt(wava[i])*fcycle), 10);
            wava[i] = Integer.toString((int)Math.round(Integer.parseInt(wava[i])/100.0), 10);
            //Logger.info("wava[" + i + "] = " + wava[i]);
        }

        for(int i=1; i< wava.length-1; i++){
            for(int j=i+1; j < wava.length; j++){
                float brt = (float)Integer.parseInt(wava[i]) / Integer.parseInt(wava[j]);
                //Logger.info("brt = " + brt);

                if(brt > 1){
                    brt = 1/brt;
                }

                //Logger.info("brt2 = " + brt);
                if(brt > 0.6){
                    wava[j] = wava[i];
                }
            }

        }

        int cnt = 0;

        for(int i=1; i < wava.length; i++){
            String samples = wava[i];
            int finds = 0;
            for(int j=0; j<cnt; j++){
                if(samples.equals(dump[j])){
                    finds = 1;
                    break;
                }
            }

            if(finds == 0){
                dump[cnt] = samples;
                //Logger.info("dump[" + cnt + "] = " + dump[cnt]);
                cnt++;
            }
        }
        cnt--;

        if(cnt >32){
            Logger.i("Ryan","sample > 32.");
        }
        //Logger.info("cnt = " + cnt);
        for(int i=0; i<= cnt-1; i++){
            for(int j= i+1; j<= cnt; j++){
                if(Long.parseLong(dump[i]) > Long.parseLong(dump[j])){
                    String tmp = dump[i];
                    dump[i] = dump[j];
                    dump[j] = tmp;
                }
            }
        }

        String bitstring = "";
        for(int i=1; i< wava.length; i++){
            String samples = wava[i];
            int j = 0;
            for(j=0; j<= cnt; j++){
                if(samples.equals(dump[j])){
                    bitstring += (j+1) + ",";
                    //Logger.info( "bitstring = " + bitstring);
                    break;
                }
            }

            if(j == cnt+1){
                Logger.i("Ryan","No Samples.");
            }
        }

        int bcnt = 1;
        for(int i = 0; i<16; i++ ){
            // 2015-04-03 周先生
            //int samps = (int)Long.parseLong(dump[i])/100;
            int samps = (int)Long.parseLong(dump[i]);

            machd[bcnt] = Integer.toHexString(samps/256);
            machd[bcnt+1] = Integer.toHexString(samps%256);
            bcnt += 2;
        }

        String[] bita = bitstring.split(",");
        int bits = bita.length;

        machd[bcnt] = Integer.toHexString(bits/256);
        machd[bcnt + 1] = Integer.toHexString(bits%256);
        bcnt += 2;
        for(int i = 0; i< bits-1;){
            machd[bcnt] = Integer.toHexString(Integer.parseInt(bita[i])) + Integer.toHexString(Integer.parseInt(bita[i+1]));
            if("".equals(machd[bcnt])){
                break;
            }
            bcnt++;
            i += 2;
        }

        String rets = "";
        for(int i= 1; i< machd.length; i++){
            if("null".equals(machd[i])){
                break;
            }
            rets += machd[i] + ",";
        }
        // Logger.info("rets = " + rets);
        String ret= rets.replaceAll("null,", "");
        return ret;
    }

    /*public static void convertDBString2Blob(SignalDBOprator dbOprator) {
        Map<Integer, IrDataFormate> rds = dbOprator.getAllMaches();
        for(int i=0; i<rds.length; i++){
            String id = rds[i][0];
            String[] mobsa = rds[i][1].split(",");
            byte[] bytes = new byte[mobsa.length];

            for(int j=0; j< mobsa.length; j++){
                bytes[j] = (byte) Integer.parseInt(mobsa[j], 16);
            }
            dbOprator.updateMatch(id, bytes);

        }
    }*/

    static byte[] getSignalData(String filePath, short keyID) {

        return null;
    }

    static int getModelTypeByFolder(String folder) {
        switch(folder) {
            case "TV":
                return 501;
            case "AC":
                return 541;
            case "ACL":
                return 591;
            case "FAN":
                return 601;
            case "DVD":
                return 621;
            case "STB":
                return 511;
            case "IPTV":
                return 521;
            default:
                return -1;
        }
    }
    static String getFolderByModelType(int modelType) {
        switch (modelType) {
            case KeyDef.DEV_TYPE_TV:
                return "TV";
            case KeyDef.DEV_TYPE_AC:
                return "AC";
            case KeyDef.DEV_TYPE_ACL:
                return "ACL";
            case KeyDef.DEV_TYPE_FAN:
                return "FAN";
            case KeyDef.DEV_TYPE_DVD:
                return "DVD";
            case KeyDef.DEV_TYPE_STB:
                return "STB";
            case KeyDef.DEV_TYPE_IPTV:
                return "IPTV";
            default:
                return "";
        }

    }

    void initKeys() {
        int keyArray[][] = {
                //TV
                {KeyDef.DEV_TYPE_TV, KeyDef.KEY_ON,             0},
                {KeyDef.DEV_TYPE_TV, KeyDef.KEY_OFF,            0},
                {KeyDef.DEV_TYPE_TV, KeyDef.KEY_TV_MENU,        29},
                {KeyDef.DEV_TYPE_TV, KeyDef.KEY_TV_NOSOUND,     37},
                {KeyDef.DEV_TYPE_TV, KeyDef.KEY_TV_SOUND_ADD,   33},
                {KeyDef.DEV_TYPE_TV, KeyDef.KEY_TV_SOUND_SUB,   34},
                {KeyDef.DEV_TYPE_TV, KeyDef.KEY_TV_CHANNEL_ADD, 35},
                {KeyDef.DEV_TYPE_TV, KeyDef.KEY_TV_CHANNEL_SUB, 36},
                {KeyDef.DEV_TYPE_TV, KeyDef.KEY_TV_UP,          25},
                {KeyDef.DEV_TYPE_TV, KeyDef.KEY_TV_DOWN,        26},
                {KeyDef.DEV_TYPE_TV, KeyDef.KEY_TV_LEFT,        27},
                {KeyDef.DEV_TYPE_TV, KeyDef.KEY_TV_RIGHT,       28},
                {KeyDef.DEV_TYPE_TV, KeyDef.KEY_TV_OK,          32},
                //风扇
                {KeyDef.DEV_TYPE_FAN, KeyDef.KEY_ON,    0},
                {KeyDef.DEV_TYPE_FAN, KeyDef.KEY_OFF,   0},
                //空气净化器
                {KeyDef.DEV_TYPE_ACL, KeyDef.KEY_ON,  0},
                {KeyDef.DEV_TYPE_ACL, KeyDef.KEY_OFF, 0},
                {KeyDef.DEV_TYPE_ACL, KeyDef.KEY_2_1, 0},
                {KeyDef.DEV_TYPE_ACL, KeyDef.KEY_2_2, 0},
                //DVD
                {KeyDef.DEV_TYPE_DVD, KeyDef.KEY_ON,            0},
                {KeyDef.DEV_TYPE_DVD, KeyDef.KEY_OFF,           0},
                {KeyDef.DEV_TYPE_DVD, KeyDef.KEY_SOUND_PLAY,    20},
                {KeyDef.DEV_TYPE_DVD, KeyDef.KEY_SOUND_STOP,    19},
                {KeyDef.DEV_TYPE_DVD, KeyDef.KEY_NO_SOUND,      35},
                {KeyDef.DEV_TYPE_DVD, KeyDef.KEY_SOUND_ADD,     4},
                {KeyDef.DEV_TYPE_DVD, KeyDef.KEY_SOUND_SUB,     5},
                {KeyDef.DEV_TYPE_DVD, KeyDef.KEY_SOUND_PRE,     22},
                {KeyDef.DEV_TYPE_DVD, KeyDef.KEY_SOUND_NEXT,    23},
                //机顶盒
                {KeyDef.DEV_TYPE_STB, KeyDef.KEY_ON,            0},
                {KeyDef.DEV_TYPE_STB, KeyDef.KEY_OFF,           0},
                {KeyDef.DEV_TYPE_STB, KeyDef.KEY_TV_MENU,       23},
                {KeyDef.DEV_TYPE_STB, KeyDef.KEY_TV_NOSOUND,    33},
                {KeyDef.DEV_TYPE_STB, KeyDef.KEY_TV_SOUND_ADD,  15},
                {KeyDef.DEV_TYPE_STB, KeyDef.KEY_TV_SOUND_SUB,  16},
                {KeyDef.DEV_TYPE_STB, KeyDef.KEY_TV_CHANNEL_ADD,13},
                {KeyDef.DEV_TYPE_STB, KeyDef.KEY_TV_CHANNEL_SUB,14},
                {KeyDef.DEV_TYPE_STB, KeyDef.KEY_TV_UP,         17},
                {KeyDef.DEV_TYPE_STB, KeyDef.KEY_TV_DOWN,       18},
                {KeyDef.DEV_TYPE_STB, KeyDef.KEY_TV_LEFT,       19},
                {KeyDef.DEV_TYPE_STB, KeyDef.KEY_TV_RIGHT,      20},
                {KeyDef.DEV_TYPE_STB, KeyDef.KEY_TV_OK,         22},
                //IPTV
                {KeyDef.DEV_TYPE_IPTV, KeyDef.KEY_ON,  0},
                {KeyDef.DEV_TYPE_IPTV, KeyDef.KEY_OFF, 0}};

        Map<Integer , Map<Integer, Integer>> keyInfo = new ArrayMap<Integer, Map<Integer, Integer>>();
        int modelKey = keyArray[0][0];
        for (int i = 0; i < keyArray.length; i++) {
            Map<Integer, Integer> modelMap = keyInfo.get(keyArray[i][0]);
            if (null == modelMap) {
                modelMap = new ArrayMap<Integer, Integer>();
            }
            modelMap.put(keyArray[i][1], keyArray[i][2]);
            keyInfo.put(modelKey, modelMap);
        }
    }

    public static int getKeyType(int devType, int index) {
        int keyType = -1;
        switch (devType) {
            case KeyDef.DEV_TYPE_TV: //电视
                switch (index) {
                    case 0:
                        keyType = KeyDef.KEY_ON;
                        break;
                    case 29:
                        keyType = KeyDef.KEY_TV_MENU;
                        break;
                    case 37:
                        keyType = KeyDef.KEY_TV_NOSOUND;
                        break;
                    case 33:
                        keyType = KeyDef.KEY_TV_SOUND_ADD;
                        break;
                    case 34:
                        keyType = KeyDef.KEY_TV_SOUND_SUB;
                        break;
                    case 35:
                        keyType = KeyDef.KEY_TV_CHANNEL_ADD;
                        break;
                    case 36:
                        keyType = KeyDef.KEY_TV_CHANNEL_SUB;
                        break;
                    case 25:
                        keyType = KeyDef.KEY_TV_UP;
                        break;
                    case 26:
                        keyType = KeyDef.KEY_TV_DOWN;
                        break;
                    case 27:
                        keyType = KeyDef.KEY_TV_LEFT;
                        break;
                    case 28:
                        keyType = KeyDef.KEY_TV_RIGHT;
                        break;
                    case 32:
                        keyType = KeyDef.KEY_TV_OK;
                        break;
                    default:
                        break;
                }
                break;
            case KeyDef.DEV_TYPE_FAN: //风扇
                break;
            case KeyDef.DEV_TYPE_ACL: //空气净化机
                switch (index) {
                    case 0:
                        keyType = KeyDef.KEY_ON;
                        break;
                }
                break;
            case KeyDef.DEV_TYPE_DVD: //DVD
                switch (index) {
                    case 0:
                        keyType = KeyDef.KEY_ON;
                        break;
                    case 20:
                        keyType = KeyDef.KEY_SOUND_PLAY;
                        break;
                    case 19:
                        keyType = KeyDef.KEY_SOUND_STOP;
                        break;
                    case 35:
                        keyType = KeyDef.KEY_NO_SOUND;
                        break;
                    case 4:
                        keyType = KeyDef.KEY_SOUND_ADD;
                        break;
                    case 5:
                        keyType = KeyDef.KEY_SOUND_SUB;
                        break;
                    case 22:
                        keyType = KeyDef.KEY_SOUND_PRE;
                        break;
                    case 23:
                        keyType = KeyDef.KEY_SOUND_NEXT;
                        break;
                    default:
                        break;
                }
                break;
            case KeyDef.DEV_TYPE_STB: //机顶盒
                switch (index) {
                    case 0:
                        keyType = KeyDef.KEY_ON;
                        break;
                    case 23:
                        keyType = KeyDef.KEY_TV_MENU;
                        break;
                    case 33:
                        keyType = KeyDef.KEY_TV_NOSOUND;
                        break;
                    case 15:
                        keyType = KeyDef.KEY_TV_SOUND_ADD;
                        break;
                    case 16:
                        keyType = KeyDef.KEY_TV_SOUND_SUB;
                        break;
                    case 13:
                        keyType = KeyDef.KEY_TV_CHANNEL_ADD;
                        break;
                    case 14:
                        keyType = KeyDef.KEY_TV_CHANNEL_SUB;
                        break;
                    case 17:
                        keyType = KeyDef.KEY_TV_UP;
                        break;
                    case 18:
                        keyType = KeyDef.KEY_TV_DOWN;
                        break;
                    case 19:
                        keyType = KeyDef.KEY_TV_LEFT;
                        break;
                    case 20:
                        keyType = KeyDef.KEY_TV_RIGHT;
                        break;
                    case 22:
                        keyType = KeyDef.KEY_TV_OK;
                        break;
                }
                break;
            case KeyDef.DEV_TYPE_IPTV: //IPTV
                break;
            default:
                break;
        }

        return keyType;
    }
    static int getSignalIndex(int modelType, int keyType) {
        int index = -1;
        switch (modelType) {
            case KeyDef.DEV_TYPE_TV: //电视
                switch (keyType) {
                    case KeyDef.KEY_ON:
                    case KeyDef.KEY_OFF:
                        index = 0;
                        break;
                    case KeyDef.KEY_TV_MENU:
                        index = 29;
                        break;
                    case KeyDef.KEY_TV_NOSOUND:
                        index = 37;
                        break;
                    case KeyDef.KEY_TV_SOUND_ADD:
                        index = 33;
                        break;
                    case KeyDef.KEY_TV_SOUND_SUB:
                        index = 34;
                        break;
                    case KeyDef.KEY_TV_CHANNEL_ADD:
                        index = 35;
                        break;
                    case KeyDef.KEY_TV_CHANNEL_SUB:
                        index = 36;
                        break;
                    case KeyDef.KEY_TV_UP:
                        index = 25;
                        break;
                    case KeyDef.KEY_TV_DOWN:
                        index = 26;
                        break;
                    case KeyDef.KEY_TV_LEFT:
                        index = 27;
                        break;
                    case KeyDef.KEY_TV_RIGHT:
                        index = 28;
                        break;
                    case KeyDef.KEY_TV_OK:
                        index = 32;
                        break;
                }
                break;
            case KeyDef.DEV_TYPE_FAN: //风扇
                break;
            case KeyDef.DEV_TYPE_ACL: //空气净化机
                switch (keyType) {
                    case KeyDef.KEY_ON:
                    case KeyDef.KEY_OFF:
                        index = 0;
                        break;
                    case KeyDef.KEY_2_1:
                    case KeyDef.KEY_2_2:
                        break;
                }
            case KeyDef.DEV_TYPE_DVD: //DVD
                switch (keyType) {
                    case KeyDef.KEY_ON:
                    case KeyDef.KEY_OFF:
                        index = 0;
                        break;
                    case KeyDef.KEY_SOUND_PLAY:
                        index = 20;
                        break;
                    case KeyDef.KEY_SOUND_STOP:
                        index = 19;
                        break;
                    case KeyDef.KEY_NO_SOUND:
                        index = 35;
                        break;
                    case KeyDef.KEY_SOUND_ADD:
                        index = 4;
                        break;
                    case KeyDef.KEY_SOUND_SUB:
                        index = 5;
                        break;
                    case KeyDef.KEY_SOUND_PRE:
                        index = 22;
                        break;
                    case KeyDef.KEY_SOUND_NEXT:
                        index = 23;
                        break;
                }
                break;
            case KeyDef.DEV_TYPE_STB: //机顶盒
                switch (keyType) {
                    case KeyDef.KEY_ON:
                    case KeyDef.KEY_OFF:
                        index = 0;
                        break;
                    case KeyDef.KEY_TV_MENU:
                        index = 23;
                        break;
                    case KeyDef.KEY_TV_NOSOUND:
                        index = 33;
                        break;
                    case KeyDef.KEY_TV_SOUND_ADD:
                        index = 15;
                        break;
                    case KeyDef.KEY_TV_SOUND_SUB:
                        index = 16;
                        break;
                    case KeyDef.KEY_TV_CHANNEL_ADD:
                        index = 13;
                        break;
                    case KeyDef.KEY_TV_CHANNEL_SUB:
                        index = 14;
                        break;
                    case KeyDef.KEY_TV_UP:
                        index = 17;
                        break;
                    case KeyDef.KEY_TV_DOWN:
                        index = 18;
                        break;
                    case KeyDef.KEY_TV_LEFT:
                        index = 19;
                        break;
                    case KeyDef.KEY_TV_RIGHT:
                        index = 20;
                        break;
                    case KeyDef.KEY_TV_OK:
                        index = 22;
                        break;
                }
                break;
            case KeyDef.DEV_TYPE_IPTV: //IPTV
                break;
            default:
                break;
        }

        return index;
    }

    static byte[] getSignalData(String filePath, int index) {
        return readSignalFile(filePath, index);
    }

    static byte[] getSignalData(String filePath, AirKeysInfo airKeysInfo, int keySequence) {
        int index;
        switch (keySequence) {
            case 15000:
                index = airKeysInfo.switchBtn*7500 +
                        airKeysInfo.modeBtn*1500 +
                        airKeysInfo.temperatureBtn*100 +
                        airKeysInfo.windSpeedBtn*25 +
                        airKeysInfo.windDirectBtn*5 +
                        airKeysInfo.keyValue + 1;
                return readSignalFile(filePath, index);
            case 3000:
                index = airKeysInfo.switchBtn*1500 +
                        airKeysInfo.modeBtn*300 +
                        airKeysInfo.temperatureBtn*20 +
                        airKeysInfo.windSpeedBtn*5 +
                        airKeysInfo.windDirectBtn + 1;
                return readSignalFile(filePath, index);
            case 14:
                index = airKeysInfo.ModifyType;
                return readSignalFile(filePath, index);
        }
        return null;
    }

    static  private byte[] readSignalFile(String filePath, int index) {
        try{
            File file = new File(filePath);//new String(filePath.getBytes("UTF-8"), "GB2312"));
            //FileOutputStream fis = new FileOutputStream(file);
            FileInputStream fos = new FileInputStream(file);
            int nSize = (int) file.length();
            byte[] buff = new byte[nSize];
            int nReadSize = fos.read(buff, 0, nSize);
            if (nReadSize <= 0) {
                return null;
            }
            int lineIndex = 0;
            int nPos = 0;
            int nBegin = 0;
            for (byte bytea : buff) {
                if (bytea == '\n') {
                    lineIndex ++;
                    if (lineIndex == index) {
                        byte[] data = new byte[nPos - nBegin];
                        System.arraycopy(buff, nBegin, data, 0, nPos - nBegin);
                        byte[] retBytes = stringToBytes(new String(data, "utf-8"));

                        return retBytes;
                    }

                    nBegin = nPos+1;
                }

                nPos++;
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }

        return null;
    }

    static public String longToString(long[] longs, boolean isUper) {
        if (null == longs) {
            return null;
        }

        String convertString = "";
        for (long aByte : longs) {
            String byteString = Long.toHexString(aByte);
            if (byteString.length() > 2) {
                byteString = byteString.substring(byteString.length() - 2);
            }
            else if (byteString.length() == 1) {
                byteString = "0" + byteString;
            }
            convertString += byteString;
            convertString += ",";
        }

        if (isUper) {
            return  convertString.toUpperCase();
        }

        return convertString;
    }

    static public String bytesToString(byte[] bytes) {
        if (null == bytes) {
            return null;
        }

        String convertString = "";
        for (int i=0 ;i<bytes.length; ++i) {
            String byteString = Integer.toHexString(bytes[i]);
            if (byteString.length() > 2) {
                byteString = byteString.substring(byteString.length() - 2);
            }
            else if (byteString.length() == 1) {
                byteString = "0" + byteString;
            }
            convertString += byteString;
            if (i != bytes.length-1) {
                convertString += ",";
            }
        }

        return convertString;
    }

    static public byte[] stringToBytes(String srcStr) {
        if (null == srcStr) {
            return null;
        }

        srcStr.indexOf(srcStr.length()-1);
        if (srcStr.charAt(srcStr.length()-1) == '\r') {
            srcStr = srcStr.substring(0, srcStr.length()-1);
        }

        String[] srcStrings = srcStr.split(",");

        int length = srcStrings.length;
        if (srcStrings[length-1].isEmpty()) {
            length--;
        }

        byte[] dstBytes = new byte[length];
        for (int i=0; i<length; ++i) {
            dstBytes[i] = Integer.valueOf(srcStrings[i], 16).byteValue();
        }

        return dstBytes;
    }

    public static byte[] getIRSignaleData(byte[] msg, int pos) {
        if (msg.length <= pos ) {
            return null;
        }
        for (int i=pos; i<msg.length;) {
            switch (msg[pos]) {
                case (byte) 0xc1:
                    pos += 3;
                    break;
                case (byte) 0xc2:
                    pos += 4;
                    break;
                case (byte) 0xc3:
                    pos++;
                    short signalLen = (short) (BytesUtil.getShort(msg, pos) >> 3);
                    pos += 2;
                    if (signalLen <= msg.length-pos) {
                        byte[] data = new byte[signalLen];
                        System.arraycopy(msg, pos, data, 0, signalLen);
                        return data;
                    }
                default:
                    return null;
            }
        }

        return null;
    }
    public static byte[] getRFSignaleData(byte[] msg, int pos) {
        if (msg.length <= pos ) {
            return null;
        }
        for (int i=pos; i<msg.length;) {
            switch (msg[pos]) {
                case (byte) 0xc1:
                    pos += 3;
                    break;
                case (byte) 0xc2:
                    pos += 3;
                    break;
                case (byte) 0xc3:
                    pos++;
                    short signalLen = (short) (BytesUtil.getShort(msg, pos) >> 3);
                    pos += 2;
                    if (signalLen <= msg.length-pos) {
                        byte[] data = new byte[signalLen];
                        System.arraycopy(msg, pos, data, 0, signalLen);
                        return data;
                    }
                default:
                    return null;
            }
        }

        return null;
    }
}
