package LogicLayer.SignalManager;

/**
 * Created by RyanLee on 2015/4/1.
 */
public class CommomHead {
    static final int HEAD_LENGTH = 4;
    byte[]  tag = new byte[2];
    byte     length;
    byte    signalType;

    CommomHead(byte[] bytes, int pos) {
        int nPos = pos;
        System.arraycopy(tag, 0, bytes, nPos, 2);
        nPos += 2;
        length = bytes[nPos];
        nPos ++;
        signalType = bytes[nPos];
    }

    CommomHead(byte length, byte signalType) {
        tag[0] = 0x55;
        tag[1] = (byte) 0xaa;
        this.length = length;
        this.signalType = signalType;
    }

    byte[] getBytes() {
        byte[] bytes = new byte[HEAD_LENGTH];
        System.arraycopy(bytes, 0, tag, 0, 2);
        bytes[2] = length;
        bytes[3] = signalType;
        return bytes;
    }

    public byte getLength() {
        return length;
    }

    public void setLength(byte length) {
        this.length = length;
    }

    public byte getSignalType() {
        return signalType;
    }

    public void setSignalType(byte signalType) {
        this.signalType = signalType;
    }
}
