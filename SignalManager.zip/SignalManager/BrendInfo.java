package LogicLayer.SignalManager;

/**
 * Created by RyanLee on 2015/4/24.
 */
public class BrendInfo {
    int formatID;
    int keySequency;

    public int getFormatID() {
        return formatID;
    }

    public void setFormatID(int formatID) {
        this.formatID = formatID;
    }

    public int getKeySequency() {
        return keySequency;
    }

    public void setKeySequency(int keySequency) {
        this.keySequency = keySequency;
    }
}
