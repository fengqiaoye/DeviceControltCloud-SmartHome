package LogicLayer.SignalManager;

import java.io.Serializable;

/**
 * Created by RyanLee on 2015/4/22.
 */
public class MatchModelInfo implements Serializable {
    String fid;
    String brandName;
    int keySequency;
    String lable;

    public String getLable() {
        return lable;
    }

    public void setLable(String lable) {
        this.lable = lable;
    }

    public String getFid() {
        return fid;
    }

    public void setFid(String fid) {
        this.fid = fid;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public int getKeySequency() {
        return keySequency;
    }

    public void setKeySequency(int keySequency) {
        this.keySequency = keySequency;
    }
}
