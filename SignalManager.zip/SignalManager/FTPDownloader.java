package LogicLayer.SignalManager;

import android.graphics.Path;
import android.util.ArrayMap;
import android.util.Log;
import android.util.SparseArray;

import org.apache.commons.io.IOUtils;
import org.apache.commons.net.ftp.FTPClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import Communication.log.Logger;

/**
 * Created by RyanLee on 2015/4/3.
 */
public class FTPDownloader extends Thread {
    final static int DOWNLOAD_STATUS_WAIT = 0;
    final static int DOWNLOAD_STATUS_PROGRESS = 1;
    final static int DOWNLOAD_STATUS_COMPLETE = 2;
    final static int DOWNLOAD_STATUS_FAILED = 3;
    final static int DOWNLOAD_STATUS_UNKNOWN = 4;

    HashMap<String, DownloadInfo> downloadMap = new HashMap<String, DownloadInfo>();
    private Lock lock = new ReentrantLock();
    boolean bStart;

    public FTPDownloader() {
        start();
    }

    public void addDownload(DownloadInfo info) {
        lock.lock();
        String key = Integer.toString(info.modelType)+ "_" + info.modelID;
        if (downloadMap.get(key) != null){
            lock.unlock();
            return;
        }
        info.status = DOWNLOAD_STATUS_WAIT;
        downloadMap.put(key, info);
        lock.unlock();
    }

    public void Start() {
        bStart = true;
    }

    public void Stop() {
        bStart = false;
    }

    public int getDownloadStatus(DownloadInfo info) {
        String key = Integer.toString(info.modelType)+ "_" + info.modelID;
        DownloadInfo downloadInfo = downloadMap.get(key);

        if (null == downloadInfo) {
            return DOWNLOAD_STATUS_UNKNOWN;
        } else {
            return downloadInfo.status;
        }
    }

    private boolean download(String url, String remoteDir, String localDir) {
        File localFile = new File(localDir);
        if (localFile.exists()) {
            return true;
        }
        FTPClient ftpClient = new FTPClient();
        ftpClient.setControlEncoding("UTF-8");
        FileOutputStream fos = null;
        boolean bRet = true;

        try {
            ftpClient.connect(url);
            //todo 获取ftp登录名和密码
            ftpClient.login("anonymous", "12345678");

            File dir = new File(localDir.substring(0, localDir.lastIndexOf("/")));
            if (!dir.exists()) {
                dir.mkdir();
            }
            fos = new FileOutputStream(localDir);

            ftpClient.setBufferSize(1024);
            //设置文件类型（二进制）
            ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
            bRet = ftpClient.retrieveFile(remoteDir, fos);
            Logger.i("Ryan", "ftpClient getfile:" + bRet);
        } catch (IOException e) {
            e.printStackTrace();
            bRet = false;
        }
        finally {
            IOUtils.closeQuietly(fos);
            try {
                ftpClient.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
                bRet = false;
            }
        }

        return bRet;
    }

    @Override
    public void run() {
        while (true) {
            try {
                sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if (!bStart) {
                continue;
            }

            lock.lock();
            if (downloadMap.size() <= 0) {
                lock.unlock();
                continue;
            }

            String key = downloadMap.keySet().iterator().next();
            DownloadInfo downloadInfo = downloadMap.get(key);
            if (null == downloadInfo) {
                lock.unlock();
                continue;
            }
            downloadInfo.status = DOWNLOAD_STATUS_PROGRESS;
            if (null != downloadInfo.handler) {
                downloadInfo.handler.handleDownloadStatus(downloadInfo);
            }
            if (download(downloadInfo.url, downloadInfo.filePath, downloadInfo.saveDir) ) {
                downloadInfo.status = DOWNLOAD_STATUS_COMPLETE;
            }
            else {
                downloadInfo.status = DOWNLOAD_STATUS_FAILED;
            }
            if (null != downloadInfo.handler) {
                downloadInfo.handler.handleDownloadStatus(downloadInfo);
            }
            downloadMap.remove(key);
            lock.unlock();
        }


    }
}
