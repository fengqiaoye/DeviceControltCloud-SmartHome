package LogicLayer.SignalManager.IrDB;

/**
 * Created by RyanLee on 2015/4/20.
 */
public class MatchInfo {
    public int score;
    public String id;
    public String fmtName;

    public MatchInfo(int score, String id, String fmtName) {
        this.score = score;
        this.id = id;
        this.fmtName = fmtName;
    }
}
