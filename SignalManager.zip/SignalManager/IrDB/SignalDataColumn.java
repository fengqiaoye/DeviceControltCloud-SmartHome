package LogicLayer.SignalManager.IrDB;

/**
 * Created by RyanLee on 2015/4/2.
 */
public interface SignalDataColumn {
    /**
     * index id
     */
    public static final String ID = "id";
    /**
     * 信号类型
     */
    public static final String SIGNALTYPE = "signaltype";
    /**
     * 家电类型
     */
    public static final String DEVICETYPE = "devicetype";
    /**
     * 家电ID
     */
    public static final String MODELID = "modelid";
    /**
     * 按键id
     */
    public static final String KEYTYPE = "keytype";
    /**
     * 具体信号值
     */
    public static final String DATA = "data";

}
