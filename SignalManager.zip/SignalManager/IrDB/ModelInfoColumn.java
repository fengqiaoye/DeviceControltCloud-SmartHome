package LogicLayer.SignalManager.IrDB;

/**
 * Created by RyanLee on 2015/4/17.
 */
public class ModelInfoColumn {
    public static final String ID = "id";
    public static final String DEVICEID = "device_id";
    public static final String CODE = "m_code";
    public static final String LABEL = "m_label";
    public static final String SEARCHSTRING = "m_search_string";
    public static final String FORMARID = "m_format_id";
    public static final String KEYFILE = "m_keyfile";
    public static final String KEYSQUENCY = "m_key_squency";
}
