package LogicLayer.SignalManager.IrDB;

/**
 * Created by RyanLee on 2015/4/14.
 */
public class SignalSaveInfoColumn {
    /**
     * 家电类型ID
     */
    public static final String MODELID = "modelid";
    /**
     * 保存类型
     */
    public static final String SAVETYPE = "savetype";
    /**
     * 信号类型
     */
    public static final String SIGNALTYPE = "signaltype";
    /**
     * 家电类型对应文件行数
     */
    public static final String KEYSEQUENCE = "keysquence";
    /**
     * 家电类型
     */
    public static final String MODELTYPE = "modeltype";
}
