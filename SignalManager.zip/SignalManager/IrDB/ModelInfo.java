package LogicLayer.SignalManager.IrDB;

import android.content.ContentValues;

/**
 * Created by RyanLee on 2015/4/17.
 */
public class ModelInfo {
    public static final String TABLE_MODEL = "model";

    public static final int COLUMN_ID = 0;
    public static final int COLUMN_DEVICEID = 1;
    public static final int COLUMN_CODE = 2;
    public static final int COLUMN_LABEL = 3;
    public static final int COLUMN_SEARCHSTRING = 4;
    public static final int COLUMN_FORMARID = 5;
    public static final int COLUMN_KEYFILE = 6;
    public static final int COLUMN_KEYSQUENCY = 7;

    public static final String[] CONTENT_PROJECTION = new String[]{
            ModelInfoColumn.ID,
            ModelInfoColumn.DEVICEID,
            ModelInfoColumn.CODE,
            ModelInfoColumn.LABEL,
            ModelInfoColumn.SEARCHSTRING,
            ModelInfoColumn.FORMARID,
            ModelInfoColumn.KEYFILE,
            ModelInfoColumn.KEYSQUENCY,
    };

    int id;
    int deviceId;
    String code;
    String label;
    String searchString;
    int formateId;
    int keyFile;
    int keySequency;

    public ModelInfo() {

    }
    public ModelInfo(int id, int deviceId, String code, String label, String searchString, int formateId, int keyFile, int keySequency) {
        this.id = id;
        this.deviceId = deviceId;
        this.code = code;
        this.label = label;
        this.searchString = searchString;
        this.formateId = formateId;
        this.keyFile = keyFile;
        this.keySequency = keySequency;
    }

    public ContentValues toContentValues() {
        ContentValues value = new ContentValues();
        value.put(ModelInfoColumn.ID, id);
        value.put(ModelInfoColumn.DEVICEID, deviceId);
        value.put(ModelInfoColumn.CODE, code);
        value.put(ModelInfoColumn.LABEL, label);
        value.put(ModelInfoColumn.SEARCHSTRING, searchString);
        value.put(ModelInfoColumn.FORMARID, formateId);
        value.put(ModelInfoColumn.KEYFILE, keyFile);
        value.put(ModelInfoColumn.KEYSQUENCY, keySequency);
        return value;
    }
}
