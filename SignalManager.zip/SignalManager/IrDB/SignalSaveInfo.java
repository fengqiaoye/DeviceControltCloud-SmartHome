package LogicLayer.SignalManager.IrDB;

import android.content.ContentValues;

/**
 * Created by RyanLee on 2015/4/14.
 */
public class SignalSaveInfo {
    public static final String TABLE_SIGNALSAVE_INFO = "signal_save_info";

    public static final int COLUMN_MODELID = 0;
    public static final int COLUMN_SAVETYPE = 1;
    public static final int COLUMN_SIGNALTYPE = 2;
    public static final int COLUMN_KETSEQUENCE = 3;
    public static final int COLUMN_MODELTYPE = 3;

    public static final String[] CONTENT_PROJECTION = new String[]{
            SignalSaveInfoColumn.MODELID,
            SignalSaveInfoColumn.SAVETYPE,
            SignalSaveInfoColumn.SIGNALTYPE,
            SignalSaveInfoColumn.KEYSEQUENCE,
            SignalSaveInfoColumn.MODELTYPE
    };

    public String modelID;
    public int saveType;
    public short signalType;
    public int keySequence;
    public int modelType;

    public SignalSaveInfo() {

    }
    public SignalSaveInfo(String modelID, short signalType, int saveType, int keySequence, int modelType) {
        this.modelID = modelID;
        this.signalType = signalType;
        this.saveType = saveType;
        this.keySequence = keySequence;
        this.modelType = modelType;
    }

    public ContentValues toContentValues() {
        ContentValues value = new ContentValues();
        value.put(SignalSaveInfoColumn.MODELID, modelID);
        value.put(SignalSaveInfoColumn.SAVETYPE, saveType);
        value.put(SignalSaveInfoColumn.SIGNALTYPE, signalType);
        value.put(SignalSaveInfoColumn.KEYSEQUENCE, keySequence);
        value.put(SignalSaveInfoColumn.MODELTYPE, modelType);
        return value;
    }
}
