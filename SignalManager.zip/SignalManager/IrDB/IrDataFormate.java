package LogicLayer.SignalManager.IrDB;

import android.content.ContentValues;

import LogicLayer.SignalManager.IrDB.IrDataFormateColumn;

/**
 * Created by RyanLee on 2015/4/7.
 */
public class IrDataFormate {

    public static final String TABLE_FORMATES = "formats";

    public static final int COLUMN_ID = 0;
    public static final int COLUMN_FID = 1;
    public static final int COLUMN_DEVICEID = 2;
    public static final int COLUMN_FORMATNAME = 3;
    public static final int COLUMN_FORMATESTRING = 4;
    public static final int COLUMN_C3RV =5;
    public static final int COLUMN_MATCHS =6;

    public static final String[] CONTENT_PROJECTION = new String[]{
            IrDataFormateColumn.ID,
            IrDataFormateColumn.FID,
            IrDataFormateColumn.DEVICEID,
            IrDataFormateColumn.FORMATNAME,
            IrDataFormateColumn.FORMATSTRING,
            IrDataFormateColumn.C3RV,
            IrDataFormateColumn.MATCHS
    };

    public int _id;
    public int fid; //
    public int deviceID;   //
    public String formatName; //
    public String formatString;    //
    public String c3rv;    //
    public byte[] matches;

    public IrDataFormate() {

    }

    public IrDataFormate(int id, int fid, int deviceID, String formatName, String formatString, String c3rv, byte[] matches) {
        this._id = id;
        this.fid = fid; //
        this.deviceID = deviceID;
        this.formatName = formatName; //
        this.formatString = formatString;
        this.c3rv = c3rv;    //
        this.matches = matches;
    }

    public ContentValues toContentValues() {
        ContentValues value = new ContentValues();
        value.put(IrDataFormateColumn.ID, _id);
        value.put(IrDataFormateColumn.FID, fid);
        value.put(IrDataFormateColumn.DEVICEID, deviceID);
        value.put(IrDataFormateColumn.FORMATNAME, formatName);
        value.put(IrDataFormateColumn.FORMATSTRING, formatString);
        value.put(IrDataFormateColumn.C3RV, c3rv);
        value.put(IrDataFormateColumn.MATCHSBYTE, matches);
        return value;
    }
}
