package LogicLayer.SignalManager.IrDB;

/**
 * Created by RyanLee on 2015/4/20.
 */
public class MatchIRBytesInfo {
    public String id;
    public byte[] matchBytes;
    public String name;
}
