package LogicLayer.SignalManager.IrDB;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by RyanLee on 2015/4/3.
 */
public class IRDatabaseHelper  extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 9;

    public IRDatabaseHelper(Context context, String name) {
        super(context, name, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        onUpgrade(sqLiteDatabase, DATABASE_VERSION, DATABASE_VERSION);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i2) {
        String signalDataTable = "create table if not exists " + SignalData.TABLE_SIGNAL +
                " ( " + SignalDataColumn.ID + " TEXT  primary key, " +
                SignalDataColumn.SIGNALTYPE + " INTEGER, " +
                SignalDataColumn.DEVICETYPE + " INTEGER, " +
                SignalDataColumn.MODELID + " INTEGER, " +
                SignalDataColumn.KEYTYPE + " INTEGER, " +
                SignalDataColumn.DATA + " BLOB );";
        sqLiteDatabase.execSQL(signalDataTable);

        String signalSaveInfotable = "create table if not exists " + SignalSaveInfo.TABLE_SIGNALSAVE_INFO +
                " ( " + SignalSaveInfoColumn.MODELID + " TEXT  primary key, " +
                SignalSaveInfoColumn.SAVETYPE + " INTEGER, " +
                SignalSaveInfoColumn.SIGNALTYPE + " INTEGER, " +
                SignalSaveInfoColumn.KEYSEQUENCE + " INTEGER, " +
                SignalSaveInfoColumn.MODELTYPE + " INTEGER );";
        sqLiteDatabase.execSQL(signalSaveInfotable);

        String airKeysInfotable = "create table if not exists " + AirKeysInfo.TABLE_AIRKEY +
                " ( " + AirKeysInfoColumn.ROOMID + " INTEGER, " +
                AirKeysInfoColumn.MODELID + " TEXT, " +
                AirKeysInfoColumn.SWITCHBTN + " INTEGER, " +
                AirKeysInfoColumn.MODELBTN + " INTEGER, " +
                AirKeysInfoColumn.TEMPERATUREBTN + " INTEGER, " +
                AirKeysInfoColumn.WINDSPEEDBTN + " INTEGER, " +
                AirKeysInfoColumn.WINDDIRECTBTN + " INTEGER, " +
                AirKeysInfoColumn.KEYVALUE + " INTEGER );";
        sqLiteDatabase.execSQL(airKeysInfotable);
    }
}
