package LogicLayer.SignalManager.IrDB;

/**
 * Created by RyanLee on 2015/4/28.
 */
public class AirKeysInfoColumn {
    public static final String ROOMID = "roomID";
    public static final String MODELID = "modelID";
    public static final String SWITCHBTN = "switchBtn";
    public static final String MODELBTN = "modeBtn";
    public static final String TEMPERATUREBTN = "temperatureBtn";
    public static final String WINDSPEEDBTN = "windSpeedBtn";
    public static final String WINDDIRECTBTN = "windDirectBtn";
    public static final String KEYVALUE = "keyValue";
}
