package LogicLayer.SignalManager.IrDB;

import android.content.ContentValues;

import LogicLayer.KeyDef;

/**
 * Created by RyanLee on 2015/4/25.
 */
public class AirKeysInfo {
    public static final String TABLE_AIRKEY = "airkey";

    public int roomID;
    public String modelID;

    public int switchBtn;
    public int modeBtn;
    public int temperatureBtn;
    public int windSpeedBtn;
    public int windDirectBtn;
    public int keyValue;

    public int ModifyType;

    public static final String[] CONTENT_PROJECTION = new String[]{
            AirKeysInfoColumn.ROOMID,
            AirKeysInfoColumn.MODELID,
            AirKeysInfoColumn.SWITCHBTN,
            AirKeysInfoColumn.MODELBTN,
            AirKeysInfoColumn.TEMPERATUREBTN,
            AirKeysInfoColumn.WINDSPEEDBTN,
            AirKeysInfoColumn.WINDDIRECTBTN,
            AirKeysInfoColumn.KEYVALUE
    };

    public boolean setKeyType(int keyType, int value) {
        switch (keyType) {
            case KeyDef.KEY_ON:
                switchBtn = 0;
                keyValue = 0;
                break;
            case KeyDef.KEY_OFF:
                switchBtn = 1;
                keyValue = 0;
                break;
            case KeyDef.KEY_AIR_AUTO:
                modeBtn = 0;
                keyValue = 1;
                break;
            case KeyDef.KEY_AIR_COLD:
                modeBtn = 1;
                keyValue = 1;
                break;
            case KeyDef.KEY_AIR_WET:
                modeBtn = 2;
                keyValue = 1;
                break;
            case KeyDef.KEY_AIR_CHANGE_AIR:
                modeBtn = 3;
                keyValue = 1;
                break;
            case KeyDef.KEY_AIR_HOT:
                modeBtn = 4;
                keyValue = 1;
                break;
            case KeyDef.KEY_AIR_TMP_ADD:
                temperatureBtn = value-16;
                if (temperatureBtn > 16) {
                    temperatureBtn = 16;
                } else if (temperatureBtn <= 0) {
                    temperatureBtn = 0;
                }
                keyValue = 2;
                break;
            case KeyDef.KEY_AIR_TMP_SUB:
                temperatureBtn = value-16;
                if (temperatureBtn <0) {
                    temperatureBtn = 0;
                }
                keyValue = 2;
                break;
            case KeyDef.KEY_AIR_WIND_AUTO:
                windSpeedBtn = 0;
                keyValue = 3;
                break;
            case KeyDef.KEY_AIR_WIND_SMALL:
                windSpeedBtn = 1;
                keyValue = 3;
                break;
            case KeyDef.KEY_AIR_WIND_MID:
                windSpeedBtn = 2;
                keyValue = 3;
                break;
            case KeyDef.KEY_AIR_WIND_STRONG:
                windSpeedBtn = 3;
                keyValue = 3;
                break;
            case KeyDef.KEY_AIR_LEFT_RIGHT: //todo 风向待确定
                windDirectBtn = 1;
                keyValue = 4;
                break;
            case KeyDef.KEY_AIR_UP_DOWN://todo 风向待确定
                windDirectBtn = 0;
                keyValue = 4;
                break;
            default:
                return false;
        }

        return true;
    }


    public ContentValues toContentValues() {
        ContentValues value = new ContentValues();
        value.put(AirKeysInfoColumn.ROOMID, roomID);
        value.put(AirKeysInfoColumn.MODELID, modelID);
        value.put(AirKeysInfoColumn.SWITCHBTN, switchBtn);
        value.put(AirKeysInfoColumn.MODELBTN, modeBtn);
        value.put(AirKeysInfoColumn.TEMPERATUREBTN, temperatureBtn);
        value.put(AirKeysInfoColumn.WINDSPEEDBTN, windSpeedBtn);
        value.put(AirKeysInfoColumn.WINDDIRECTBTN, windDirectBtn);
        value.put(AirKeysInfoColumn.KEYVALUE, keyValue);
        return value;
    }


}
