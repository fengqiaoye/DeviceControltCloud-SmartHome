package LogicLayer.SignalManager.IrDB;

import android.content.ContentValues;

import java.sql.Timestamp;

import LogicLayer.SignalManager.IrDB.SignalDataColumn;

/**
 * Created by RyanLee on 2015/4/1.
 */
public class SignalData {

    public static final String TABLE_SIGNAL = "signals";

    public static final int COLUMN_ID = 0;
    public static final int COLUMN_SIGNALTYPE = 1;
    public static final int COLUMN_DEVICETYPE = 2;
    public static final int COLUMN_MODELID = 3;
    public static final int COLUMN_KEYTYPE = 4;
    public static final int COLUMN_DATA = 5;

    public static final String[] CONTENT_PROJECTION = new String[]{
            SignalDataColumn.ID,
            SignalDataColumn.SIGNALTYPE,
            SignalDataColumn.DEVICETYPE,
            SignalDataColumn.MODELID,
            SignalDataColumn.KEYTYPE,
            SignalDataColumn.DATA,
    };

    String _id;
    public short signalType; //
    public int deviceType;
    public String modelID; //
    public int keyType;    //
    public byte[] data;    //

    public SignalData() {

    }
    public SignalData(short signalType, int deviceType, String modelID, int keyType, byte[] data) {
        this._id = modelID +"_"+ Integer.toString(keyType);
        this.signalType = signalType;
        this.deviceType = deviceType;
        this.modelID = modelID;
        this.keyType = keyType;
        this.data = data;
    }

    public void setSignalDatas(short signalType, int deviceType, String modelID, int keyType, byte[] data) {
        this._id = modelID +"_"+ Integer.toString(keyType);
        this.signalType = signalType;
        this.deviceType = deviceType;
        this.modelID = modelID;
        this.keyType = keyType;
        this.data = data;
    }

    public ContentValues toContentValues() {
        ContentValues value = new ContentValues();
        value.put(SignalDataColumn.ID, _id);
        value.put(SignalDataColumn.SIGNALTYPE, signalType);
        value.put(SignalDataColumn.DEVICETYPE, deviceType);
        value.put(SignalDataColumn.MODELID, modelID);
        value.put(SignalDataColumn.KEYTYPE, keyType);
        value.put(SignalDataColumn.DATA, data);
        return value;
    }

    public byte[] getData() {
        return data;
    }
}
