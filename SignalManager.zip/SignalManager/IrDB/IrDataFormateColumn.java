package LogicLayer.SignalManager.IrDB;

/**
 * Created by RyanLee on 2015/4/7.
 */
public class IrDataFormateColumn {
    public static final String ID = "id";
    public static final String FID = "fid";
    public static final String DEVICEID = "device_id";
    public static final String FORMATNAME = "format_name";
    public static final String FORMATSTRING = "format_string";
    public static final String C3RV = "c3rv";
    public static final String MATCHS = "matchs";
    public static final String MATCHSBYTE = "matchs_byte";
}
