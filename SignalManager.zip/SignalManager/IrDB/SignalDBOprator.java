package LogicLayer.SignalManager.IrDB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import LogicLayer.SignalManager.BrendInfo;
import LogicLayer.SignalManager.MatchModelInfo;

/**
 * Created by RyanLee on 2015/4/1.
 */
public class SignalDBOprator {
    private Context context;
    Map<Integer, IrDataFormate> matchDatas;
    Map<String, Integer> modelIDMap;
    Map<String, BrendInfo> allSearchString;
    private SQLiteDatabase mDatabase;
    public static final String DATABASE_NAME = "ird.db";
    public static final String DATABASE_PATH = "/data/data/com.cooxm.xiaomi/databases/ird.db";

    public void init(Context context){
        this.context = context;
        getDatabase(context);
    }

    public SignalData signalDataQuery(String modelID, short keyType) {
        String id = modelID +"_" + Short.toString(keyType);
        Cursor cursor = mDatabase.query(SignalData.TABLE_SIGNAL, SignalData.CONTENT_PROJECTION, SignalDataColumn.ID + "=" + id, null, null, null, null);
        SignalData signalData = null;
        if(cursor != null && cursor.moveToFirst()) {
            short signalType = cursor.getShort(SignalData.COLUMN_SIGNALTYPE);
            int deviceType = cursor.getShort(SignalData.COLUMN_DEVICETYPE);
            byte[] data = cursor.getBlob(SignalData.COLUMN_DATA);

            signalData = new SignalData(signalType,deviceType, modelID,keyType,data);
            cursor.close();
        }
        return signalData;
    }

    SQLiteDatabase getDatabase(Context context) {
        if (mDatabase != null) {
            return mDatabase;
        }

        IRDatabaseHelper helper = new IRDatabaseHelper(context,
                DATABASE_NAME);
        mDatabase = helper.getWritableDatabase();
        return mDatabase;
    }

    public MatchIRBytesInfo[] getAllMachesBytes() {
        String[] clomns = new String[] {
                IrDataFormateColumn.FID,
                IrDataFormateColumn.MATCHSBYTE,
                IrDataFormateColumn.FORMATNAME
        };
        Cursor cursor = mDatabase.query(IrDataFormate.TABLE_FORMATES, clomns, null, null, null, null, null);

        int count = cursor.getCount();
        MatchIRBytesInfo[] bytesInfos = new MatchIRBytesInfo[count];
        if(cursor.moveToFirst()) {
            for (int i=0;; i++) {
                MatchIRBytesInfo irBytesInfo = new MatchIRBytesInfo();
                irBytesInfo.id = cursor.getString(0);
                irBytesInfo.matchBytes = cursor.getBlob(1);
                irBytesInfo.name = cursor.getString(2);
                bytesInfos[i] = irBytesInfo;

                if (!cursor.moveToNext()) {
                    break;
                }
            }
            cursor.close();
        }

        return bytesInfos ;
    }

    public Map<String, Integer> getAllModelIDMap() {
        if (null == modelIDMap) {
            getAllMaches();
        }
        return modelIDMap;
    }
    public Map<Integer, IrDataFormate> getAllMaches() {
        if (null != matchDatas) {
            return matchDatas;
        }

        Cursor cursor = mDatabase.query(IrDataFormate.TABLE_FORMATES, IrDataFormate.CONTENT_PROJECTION, null, null, null, null, null);

        modelIDMap = new HashMap<String, Integer>();
        matchDatas = new HashMap<>();
        if(cursor.moveToFirst()) {
            for (;;) {
                IrDataFormate formate = new IrDataFormate();
                formate._id = cursor.getInt(0);
                formate.fid = cursor.getInt(1);
                formate.deviceID = cursor.getInt(2);
                formate.formatName = cursor.getString(3);
                formate.formatString = cursor.getString(4);
                formate.c3rv = cursor.getString(5);
                formate.matches = cursor.getBlob(6);

                matchDatas.put(formate.fid, formate);
                modelIDMap.put(formate.formatName, formate.fid);
                if (!cursor.moveToNext()) {
                    break;
                }
            }
            cursor.close();
        }

        return matchDatas ;
    }

    public int getMaxModelID(){
        int max_model_id = 0;
        Cursor cursor = mDatabase.query(SignalData.TABLE_SIGNAL,
                new String[]{SignalDataColumn.MODELID},
                null,
                null,
                null, null, null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                try{
                    int model_id = Integer.parseInt(cursor.getString(0));
                    if(model_id>max_model_id){
                        max_model_id = model_id;
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }

            }
            cursor.close();
        }
        return max_model_id;

    }

    public void updateMatch(String id, byte[] match) {
        ContentValues value  = new ContentValues();
        value.put(IrDataFormateColumn.MATCHSBYTE, match);
        mDatabase.update(IrDataFormate.TABLE_FORMATES, value, IrDataFormateColumn.ID+"=?", new String[]{id});
    }

    public void addOneSignalData(String modelID, int deviceType, short keyType, short signalType, byte[] signalDatas) {
        SignalData signalData = new SignalData(signalType, deviceType, modelID, keyType, signalDatas);
        ContentValues value = signalData.toContentValues();
        long nRet = mDatabase.insert(SignalData.TABLE_SIGNAL, null, value);
    }

    public boolean getOneSignalData(String modelID, int keyType, SignalData signalData) {
        String id = modelID +"_"+ Integer.toString(keyType);
        Cursor cursor = mDatabase.query(SignalData.TABLE_SIGNAL,
                SignalData.CONTENT_PROJECTION,
                SignalDataColumn.ID + "=?",
                new String[]{id},
                null, null, null);

        if(cursor != null && cursor.moveToFirst()) {
            short signalType = cursor.getShort(SignalData.COLUMN_SIGNALTYPE);
            byte[] data = cursor.getBlob(SignalData.COLUMN_DATA);
            int deviceType = cursor.getInt(SignalData.COLUMN_DEVICETYPE);
            if (null != signalData) {
                signalData.setSignalDatas(signalType, deviceType, modelID, keyType, data);
            }
            cursor.close();
            return true;
        }

        return false;
    }

    public Map<Short, byte[]> getDeviceSignalDatas(short deviceType) {
        Cursor cursor = mDatabase.query(SignalData.TABLE_SIGNAL,
                new String[]{SignalDataColumn.KEYTYPE, SignalDataColumn.DATA},
                SignalData.COLUMN_DEVICETYPE + "=?",
                new String[]{String.valueOf(deviceType)},
                null, null, null);

        if(cursor != null && cursor.moveToFirst()) {
            Map<Short, byte[]> deviceSignals = new HashMap<Short, byte[]>();
            for (int i=0;; i++) {
                short keyType = cursor.getShort(0);
                byte[] data = cursor.getBlob(1);
                deviceSignals.put(keyType, data);
                if (!cursor.moveToNext()) {
                    break;
                }
            }
            cursor.close();
            return deviceSignals;
        }

        return null;
    }

    public List<SignalData> getAllDeviceSignalDatas() {
        Cursor cursor = mDatabase.query(SignalData.TABLE_SIGNAL,
                SignalData.CONTENT_PROJECTION,
                null,null,null, null, null);

        if(cursor != null && cursor.moveToFirst()) {
            List<SignalData> deviceSignals = new ArrayList<SignalData>();
            for (;;) {
                SignalData sd = new SignalData();
                sd.signalType = cursor.getShort(SignalData.COLUMN_SIGNALTYPE);
                sd.deviceType = cursor.getInt(SignalData.COLUMN_DEVICETYPE);
                sd.modelID = cursor.getString(SignalData.COLUMN_MODELID);
                sd.keyType = cursor.getInt(SignalData.COLUMN_KEYTYPE);
                sd.data = cursor.getBlob(SignalData.COLUMN_DATA);
                deviceSignals.add(sd);

                if (!cursor.moveToNext()) {
                    break;
                }
            }

            cursor.close();
            return deviceSignals;
        }

        return null;
    }

    public void deleteOneSignalSaveInfo(String modelID) {
        mDatabase.delete(SignalSaveInfo.TABLE_SIGNALSAVE_INFO, SignalSaveInfoColumn.MODELID + "=" + modelID, null);
    }

    public void addOneSignalSaveInfo(SignalSaveInfo signalSaveInfo) {
        ContentValues value = signalSaveInfo.toContentValues();
        long nRet = mDatabase.insert(SignalSaveInfo.TABLE_SIGNALSAVE_INFO, null, value);
    }

    public Map<String, SignalSaveInfo> getAllSignalSaveInfo() {
        Map<String, SignalSaveInfo> signalSaveInfoMap = new HashMap<String, SignalSaveInfo>();
        Cursor cursor = mDatabase.query(SignalSaveInfo.TABLE_SIGNALSAVE_INFO,
                SignalSaveInfo.CONTENT_PROJECTION,
                null,
                null,
                null, null, null);

        if(cursor != null && cursor.moveToFirst()) {
            for (int i=0;; i++) {
                String modelID = cursor.getString(0);
                SignalSaveInfo signalSaveInfo = new SignalSaveInfo();
                signalSaveInfo.modelID = modelID;
                signalSaveInfo.saveType = cursor.getInt(1);
                signalSaveInfo.signalType = cursor.getShort(2);
                signalSaveInfo.keySequence = cursor.getShort(3);
                signalSaveInfoMap.put(modelID, signalSaveInfo);
                if (!cursor.moveToNext()) {
                    break;
                }
            }
            cursor.close();
            return signalSaveInfoMap;
        }

        return signalSaveInfoMap;
    }

    public  MatchModelInfo getModel(int fid){
        Cursor cursor = mDatabase.query(ModelInfo.TABLE_MODEL,
                new String[]{ModelInfoColumn.SEARCHSTRING, ModelInfoColumn.LABEL, ModelInfoColumn.KEYSQUENCY, ModelInfoColumn.CODE},
                ModelInfoColumn.FORMARID + "=?",
                new String[]{Integer.toString(fid)},
                null, null, null);

        MatchModelInfo brandInfo = new MatchModelInfo();
        if(cursor != null && cursor.moveToFirst()) {
            for (;!cursor.isAfterLast();cursor.moveToNext()) {
                String searchString = cursor.getString(0);
                String label = cursor.getString(1);
                if (null==searchString || searchString.length()==0) {
                    continue;
                }
                if (searchString.equals("其他品牌 ")) {
                    continue;
                }

                brandInfo.setFid(Integer.toString(fid));
                brandInfo.setKeySequency(cursor.getInt(2));
                int spaceIndex = searchString.indexOf(" ");

                if (spaceIndex > 0) {
                    if(null==label || label.length()==0){
                        brandInfo.setBrandName(searchString);
                        brandInfo.setLable(searchString.substring(0, spaceIndex) + "-" + cursor.getString(3));
                    } else {
                        brandInfo.setBrandName(searchString.substring(spaceIndex + 1));
                        brandInfo.setLable(searchString.substring(0, spaceIndex) + "-" + label);
                    }
                }
            }
        }

        if(cursor != null) {
            cursor.close();
        }

        return brandInfo;
    }
    /** 返回值：<  model_name,品牌 > */
    public  ArrayList<MatchModelInfo> getModels(List<MatchInfo> fids){
        ArrayList<MatchModelInfo> models = new ArrayList<>();

        for(int i=0;i<fids.size();i++) {
            Cursor cursor = mDatabase.query(ModelInfo.TABLE_MODEL,
                    new String[]{ModelInfoColumn.SEARCHSTRING, ModelInfoColumn.LABEL, ModelInfoColumn.KEYSQUENCY, ModelInfoColumn.CODE},
                    ModelInfoColumn.FORMARID + "=?",
                    new String[]{fids.get(i).id},
                    null, null, null);
            if(cursor != null && cursor.moveToFirst()) {
                for (;!cursor.isAfterLast();cursor.moveToNext()) {
                    String searchString = cursor.getString(0);
                    String label = cursor.getString(1);
                    if (null==searchString || searchString.length()==0) {
                        continue;
                    }
                    if (searchString.equals("其他品牌 ")) {
                        continue;
                    }

                    MatchModelInfo brandInfo = new MatchModelInfo();
                    brandInfo.setFid(fids.get(i).fmtName);
                    brandInfo.setKeySequency(cursor.getInt(2));
                    int spaceIndex = searchString.indexOf(" ");

                    if (spaceIndex > 0) {
                        if(null==label || label.length()==0){
                            brandInfo.setBrandName(searchString);
                            brandInfo.setLable(searchString.substring(0, spaceIndex) + "-" + cursor.getString(3));
                        } else {
                            brandInfo.setBrandName(searchString.substring(spaceIndex + 1));
                            brandInfo.setLable(searchString.substring(0, spaceIndex) + "-" + label);
                        }
                    }

                    models.add(brandInfo);
                }
            }

            if(cursor != null) {
                cursor.close();
            }
        }


        return models;
    }

    public Map<String, BrendInfo> getAllSearchString() {
        if (allSearchString != null) {
            return allSearchString;
        }
        Map<String, BrendInfo> allSearchString = new HashMap<String, BrendInfo>();
        Cursor cursor = mDatabase.query(ModelInfo.TABLE_MODEL,
                new String[]{ModelInfoColumn.SEARCHSTRING, ModelInfoColumn.FORMARID, ModelInfoColumn.KEYSQUENCY},
                null,
                null,
                null, null, null);

        if(cursor != null && cursor.moveToFirst()) {
            for (;;) {
                String searchString = cursor.getString(0);
                int formateId = cursor.getInt(1);
                int keySequency = cursor.getInt(2);
                if (null==searchString || searchString.length()==0) {
                    continue;
                }

                String[] brend = searchString.split(" ");
                int brendSize = brend.length;
                if (brendSize == 1) {

                }else if (brendSize > 1) {
                    for (int i=1; i<brendSize; ++i) {
                        if (brend[i].length() > 1) {
                            BrendInfo brendInfo = new BrendInfo();
                            brendInfo.setFormatID(formateId);
                            brendInfo.setKeySequency(keySequency);
                            allSearchString.put(brend[0] + brend[i], brendInfo);
                        }
                    }
                }

                if (!cursor.moveToNext()) {
                    break;
                }
            }
        }

        if(cursor != null) {
            cursor.close();
        }

        return allSearchString;
    }


    public Map<Integer, ArrayList<AirKeysInfo>> getAllAirKeysInfos() {
        Map<Integer, ArrayList<AirKeysInfo>> allAirKeysInfos = new HashMap<Integer, ArrayList<AirKeysInfo>>();
        Cursor cursor = mDatabase.query(AirKeysInfo.TABLE_AIRKEY,
                AirKeysInfo.CONTENT_PROJECTION,
                null,
                null,
                null, null, null);

        if(cursor != null && cursor.moveToFirst()) {
            for (;;) {
                AirKeysInfo airKeysInfo = new AirKeysInfo();
                airKeysInfo.roomID = cursor.getInt(0);
                airKeysInfo.modelID = cursor.getString(1);
                airKeysInfo.switchBtn = cursor.getInt(2);
                airKeysInfo.modeBtn = cursor.getInt(3);
                airKeysInfo.temperatureBtn = cursor.getInt(4);
                airKeysInfo.windSpeedBtn = cursor.getInt(5);
                airKeysInfo.windDirectBtn = cursor.getInt(6);
                airKeysInfo.keyValue = cursor.getInt(7);

                ArrayList<AirKeysInfo> airKeysInfoList = allAirKeysInfos.get(airKeysInfo.roomID);
                if (null == airKeysInfoList) {
                    airKeysInfoList = new ArrayList<AirKeysInfo>();
                }
                airKeysInfoList.add(airKeysInfo);
                allAirKeysInfos.put(airKeysInfo.roomID, airKeysInfoList);

                if (!cursor.moveToNext()) {
                    break;
                }
            }
        }

        if(cursor != null) {
            cursor.close();
        }

        return allAirKeysInfos;
    }

    public void addAirKeysInfo(AirKeysInfo airKeysInfo) {
        ContentValues value = airKeysInfo.toContentValues();
        long nRet = mDatabase.insert(AirKeysInfo.TABLE_AIRKEY, null, value);
    }
    public void removeAirKeysInfo(int roomID, String modelID){
        mDatabase.delete(AirKeysInfo.TABLE_AIRKEY, AirKeysInfoColumn.ROOMID + "==? and " +
                AirKeysInfoColumn.MODELID + "==?", new String[]{String.valueOf(roomID), modelID});
    }
    public void changeAirKeysInfo(AirKeysInfo airKeysInfo){
        ContentValues value = airKeysInfo.toContentValues();
        int nRet = mDatabase.update(AirKeysInfo.TABLE_AIRKEY, value, AirKeysInfoColumn.ROOMID + "==? and " +
                AirKeysInfoColumn.MODELID + "==?", new String[]{String.valueOf(airKeysInfo.roomID), airKeysInfo.modelID});
    }
}
