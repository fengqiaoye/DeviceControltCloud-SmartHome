package LogicLayer.SignalManager;

import android.content.Context;
import android.content.Intent;

import com.android.turingcatlogic.database.DatabaseOperate;
import com.android.turingcatlogic.database.SensorApplianceContent;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Communication.ICallBackHandler;
import Communication.JsonProtocol.CmdDef;
import Communication.log.Logger;
import LogicLayer.CmdInterface;
import LogicLayer.DeviceManager.SensorDevInfo;
import LogicLayer.DeviceManager.SensorTypeDef;
import LogicLayer.KeyDef;
import LogicLayer.LogicDef;
import LogicLayer.SignalManager.IrDB.AirKeysInfo;
import LogicLayer.SignalManager.IrDB.IrDataFormate;
import LogicLayer.SignalManager.IrDB.SignalDBOprator;
import LogicLayer.SignalManager.IrDB.SignalData;
import LogicLayer.SignalManager.IrDB.SignalSaveInfo;
import LogicLayer.SystemSetting.SystemSetting;

/**
 * Created by RyanLee on 2015/4/1.
 */
public class SignalManager implements IDownloadHandler{
    static final public int RCVMODE_NORMAL = 0;
    static final public int RCVMODE_STUDY = 1;
    static final public int RCVMODE_MATCHMODEL = 2;

    static final public int INFORMTYPE_MATCHID = 1;
    static final public int INFORMTYPE_STUDYID = 2;

    static final public int SAVETYPE_DB = 1;
    static final public int SAVETYPE_FILE = 2;

    static final public String SIGNAL_ACTION_MATCH = "com.cooxm.xiaomi.signalmatch";
    static final public String SIGNAL_ACTION_STUDY = "com.cooxm.xiaomi.signalstudy";
    static final public String SIGNAL_ACTION_DOWNLOAD = "com.cooxm.xiaomi.signaldownload";

    @Override
    public void handleDownloadStatus(DownloadInfo downloadInfo) {
        if (FTPDownloader.DOWNLOAD_STATUS_COMPLETE == downloadInfo.status) {
            saveIRFile(downloadInfo.modelID, downloadInfo.modelType);
            informUI(SIGNAL_ACTION_DOWNLOAD, downloadInfo.modelID, true);
        }
        else if (FTPDownloader.DOWNLOAD_STATUS_FAILED == downloadInfo.status) {
            informUI(SIGNAL_ACTION_DOWNLOAD, downloadInfo.modelID, false);
        }
    }

    private class KeyInfo {
        String modelID;
        int deviceType;
        short keyType;
    }

    private class SendSignalInfo {
        byte[] signalData;
        int signalType;
    }

    int  rcvMode = RCVMODE_NORMAL;
    int currentMatchModelType = -1;
    KeyInfo keyInfo = new KeyInfo();
    FTPDownloader downloader = new FTPDownloader();
    SignalDBOprator signalDBOprator = new SignalDBOprator();
    Context context;
    Map<String, SignalSaveInfo> signalSaveInfoMap;
    int currentKeySequence = 0;
    AirConStatusManager airConStatusManager = new AirConStatusManager();

    private static SignalManager singleton = new SignalManager();

    public static SignalManager instance(){
        return singleton;
    }

    /**
     * 说明：初始化信号管理类
     * 参数：1.context activity上下文
     * 返回值：无
     * */
    public void init(Context context) {
        this.context = context;
        signalDBOprator.init(context);
        airConStatusManager.init(signalDBOprator);
        downloader.Start();

        signalSaveInfoMap = signalDBOprator.getAllSignalSaveInfo();
    }
    /**
     * 说明：设置数据接收模式
     * 参数：mode 信号接收模式 RCVMODE_NORMAL（正常模式），RCVMODE_STUDY（信号学习模式），RCVMODE_MATCHMODEL（遥控型号匹配模式）
     * 返回值：无
     * */
    public void setStudyMode(int mode) {
        rcvMode = mode;
    }

    public int getStudyMode() {
        return rcvMode;
    }

    public void setMachModelType(int modelType) {
        currentMatchModelType = modelType;
    }


    /**
     * 单个按钮匹配的时候，生成新的ModelID
     * @return
     */
    public String getNewModelID(){
        int max_mode_id = signalDBOprator.getMaxModelID();
        if(max_mode_id<100000){  // 新生成的从100000开始
            max_mode_id =  100000;
        }

        String mode_id = ""+(max_mode_id+1);

        return mode_id;
    }

    /**
     * 说明：设置要学习的设备
     * 参数：1.modelID 家电设备类型
     *      2.keyType 按键类型
     * 返回值：
     * */
    public void setCurrentStudyDevice( String modelID ,int deviceType, short keyType) {
        keyInfo.keyType = keyType;
        keyInfo.modelID = modelID;
        keyInfo.deviceType = deviceType;
    }

    /**
     * 说明：处理接收到的无线信号
     * 参数：1.signalType 信号类型，同发射器设备类型一致;
     *      2.signalData 上报的无线信号内容
     * 返回值：true（成功），false（失败）
     * */
    public boolean handleSignalData(SensorDevInfo sensorDevInfo, short subDevType, byte[] signalData) {
        switch (rcvMode) {
            case RCVMODE_NORMAL:
                KeyInfo matchKeyInfo = matchSignalData(subDevType, signalData);
                if (null != matchKeyInfo) {
                    DatabaseOperate operate = DatabaseOperate.instance();
                    if (subDevType == SensorTypeDef.SENSOR_INFRARED_RCV) {
                        int roomType = sensorDevInfo.getRoomType();
                        int roomID = sensorDevInfo.getRoomID();
                        List<SensorApplianceContent> appliances = operate.applianceQuery(matchKeyInfo.modelID, roomID);
                        if (appliances.size() > 0) {
                            SensorApplianceContent content = appliances.get(0);
                            reportToCloud(roomType, roomID, content.sensorApplianceId, matchKeyInfo.deviceType, matchKeyInfo.keyType);
                            return true;
                        }
                    } else {
                        List<SensorApplianceContent> appliances = operate.applianceQuery(matchKeyInfo.modelID, -1);
                        if (appliances.size() > 0) {
                            SensorApplianceContent content = appliances.get(0);
                            reportToCloud(content.roomType, content.roomId, content.sensorApplianceId, matchKeyInfo.deviceType, matchKeyInfo.keyType);
                            return true;
                        }
                    }
                }
                return false;
            case RCVMODE_STUDY:
                short signalType = 0;
                switch (subDevType) {
                    case SensorTypeDef.SENSOR_INFRARED_RCV:
                        signalType = SensorTypeDef.SENSOR_INFRARED_SEND;
                        break;
                    case SensorTypeDef.SENSOR_RF_315_ECV:
                        signalType = SensorTypeDef.SENSOR_RF_315_SEND;
                        break;
                    case SensorTypeDef.SENSOR_RF_433_RCV:
                        signalType = SensorTypeDef.SENSOR_RF_433_SEND;
                        break;
                }
                saveSignalData(signalType, keyInfo, signalData);
                return true;
            case RCVMODE_MATCHMODEL:
                return matchModel(signalData, currentMatchModelType);
        }

        return false;
    }

    /**
     * 说明：添加一个房间内的空调
     * 参数：roomID 房间ID
     *      modelID 型号ID
     * 返回值：无
     * */
    public void addAirDevice(int roomID, String modelID) {
        AirKeysInfo airKeysInfo = new AirKeysInfo();
        airKeysInfo.roomID = roomID;
        airKeysInfo.modelID = modelID;
        airConStatusManager.addAirCondition(airKeysInfo);
    }

    /**
     * 说明：控制下发无线信号
     * 参数：1.roomID 房间ID
     *      2.modelID 要控制的设备类型
     *      3.keyType 控制的按键类型
     *      4.simpleSignal 信号是否单一，空调信号为复合信号
     * 返回值：true（成功），false（失败）
     * */
    public boolean ctrrlDevices(List<SignalInfo> signalInfos) {
        boolean bRet = true;
        for (SignalInfo info : signalInfos) {
            bRet &= ctrlDevice(info);
        }

        return  bRet;
    }

    public boolean ctrlDevice(SignalInfo signal) {
        return ctrlDevice(signal, null);
    }

    public boolean ctrlDevice(SignalInfo signal, AirKeysInfo airKeysInfo) {
        SendSignalInfo sendSignalInfo = findSignalData(signal, airKeysInfo);
        if (null != sendSignalInfo) {
            return sendSignalData(signal.roomId, sendSignalInfo);
        }
        return false;
    }

    /**
     * 说明：通过设备型号获取所有红外按键信息
     * 参数：model 具体设备型号
     * 返回值：按键信息列表Map<keyType, signalData>
     * */
//    public Map<Short, byte[]> getSignalsByModel(String model) {
//        Map<Short, byte[]> signals = getLocalSignals(model);
//        if (null != signals) {
//            return signals;
//        }
//
//        signals = getCloudSignals(model);
//        if (null != signals) {
//            return signals;
//        }
//        return null;
//    }

    /**
     * 说明：删除下载的红外库文件
     * 参数：modelID 型号ID
     * 返回值：无
     * */
    public boolean removeIRFile(int roomID, String modelID) {
        SignalSaveInfo signalSaveInfo = signalSaveInfoMap.get(modelID);
        if (null == signalSaveInfo) {
            return false;
        }
        boolean bRet = false;
        if (signalSaveInfo.saveType == SAVETYPE_DB) {
            signalDBOprator.deleteOneSignalSaveInfo(modelID);
            bRet = true;
        }
        else {
            File file = new File(context.getFilesDir().getPath() + "/" + modelID + ".txt");
            bRet = file.delete();
        }
        signalSaveInfoMap.remove(modelID);
        airConStatusManager.removeAirCondition(roomID, modelID);

        return bRet;
    }


    public Map<String, BrendInfo> getBrends(String seeds, Map<String, BrendInfo> existBrends) {
        Map<String, BrendInfo> brends = new HashMap<String, BrendInfo>();
        Map<String, BrendInfo> allBrends;
        if (existBrends == null) {
            allBrends = signalDBOprator.getAllSearchString();
        }
        else {
            allBrends = existBrends;
        }

        for(Map.Entry<String, BrendInfo> entry:allBrends.entrySet()){
            String key = entry.getKey();
            if (key.length() >= seeds.length()) {
                if (key.substring(0, seeds.length()).equals(seeds)) {
                    brends.put(entry.getKey(), entry.getValue());
                }
            }

        }
        return brends;
    }

    private void saveSignalData(short signalType, KeyInfo keyInfo, byte[] signalData){
        signalDBOprator.addOneSignalData(keyInfo.modelID, keyInfo.deviceType, keyInfo.keyType, signalType, signalData);
        SignalSaveInfo signalSaveInfo = new SignalSaveInfo(keyInfo.modelID, signalType, SAVETYPE_DB, 0, keyInfo.deviceType);
        signalSaveInfoMap.put(keyInfo.modelID, signalSaveInfo);
        signalDBOprator.addOneSignalSaveInfo(signalSaveInfo);

        informUI(SIGNAL_ACTION_STUDY, 1);
    }

    private KeyInfo  matchSignalData(short subDevType, byte[] signalData) {
        List<SignalData> signalDatas = signalDBOprator.getAllDeviceSignalDatas();
        if (null == signalDatas) {
            return null;
        }

        int RF_SIGNAL_HEAD_LENGTH = 13;
        int IR_SIGNAL_HEAD_LENGTH = 15;
        boolean isIRSignal = (subDevType == SensorTypeDef.SENSOR_INFRARED_RCV);
        byte[] srcSignal =  isIRSignal ?
                IRUtil.getIRSignaleData(signalData, IR_SIGNAL_HEAD_LENGTH) :
                IRUtil.getRFSignaleData(signalData, RF_SIGNAL_HEAD_LENGTH);
        if (null == srcSignal) {
            return null;
        }

        for (SignalData sd: signalDatas) {
            if (sd.signalType != subDevType-1) {//发送信号和接收信号类型差1
                continue;
            }
            if (signalData.length != sd.data.length) {
                continue;
            }
           byte[] dstSignal = isIRSignal ?
                    IRUtil.getIRSignaleData(sd.data, IR_SIGNAL_HEAD_LENGTH) :
                    IRUtil.getRFSignaleData(sd.data, RF_SIGNAL_HEAD_LENGTH);
            if (null == dstSignal) {
                continue;
            }
            if (Arrays.equals(srcSignal, dstSignal)) {
                KeyInfo keyInfo = new KeyInfo();
                keyInfo.modelID = sd.modelID;
				keyInfo.deviceType = sd.deviceType;
                keyInfo.keyType = (short) sd.keyType;

                return keyInfo;
            }
        }

        if (isIRSignal) {
            String strSignal = IRUtil.bytesToString(srcSignal).toUpperCase();
            String path = context.getFilesDir().getPath() + "/TV";
            File file = new File(path);
            File [] files = file.listFiles();
            for (File afile: files) {
                BufferedReader reader = null;
                try {
                    reader =new BufferedReader(new FileReader(afile));
                    for (int i = 0;  ; i++) {
                        String line = reader.readLine();
                        if (line.contains(strSignal)) {
                            KeyInfo keyInfo = new KeyInfo();
                            keyInfo.modelID = afile.getName().substring(0, afile.getName().indexOf('.'));
                            keyInfo.deviceType = KeyDef.DEV_TYPE_TV;
                            keyInfo.keyType = (short) IRUtil.getKeyType(KeyDef.DEV_TYPE_TV, i);
                            reader.close();
                            return keyInfo;
                        }
                    }
                } catch (IOException e) {
                    if (null != reader) {
                        try {
                            reader.close();
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                    }
                    e.printStackTrace();
                }

            }
            //todo 在文件中查找
        }
        return  null;//TODO
    }

    private int getFormateID(String modelID) {
        Map<String, Integer> allModelIDMap = signalDBOprator.getAllModelIDMap();
        if (null == allModelIDMap || !allModelIDMap.containsKey(modelID)) {
            return 0;
        }
        return allModelIDMap.get(modelID);
    }

    /**
     * airKeysInfo 在空调调用改变多个值的时候需要赋值，其它可为null
     * */
    private SendSignalInfo findSignalData(SignalInfo signal, AirKeysInfo airKeysInfo) {
        //操作门锁的开关
        if (signal.modelType == 2221) {
            SendSignalInfo sendSignalInfo = new SendSignalInfo();
            sendSignalInfo.signalType = SensorTypeDef.SENSOR_LOCK;
            sendSignalInfo.signalData = new byte[1];
            sendSignalInfo.signalData[0] = (byte)((signal.keyType == KeyDef.KEY_ON) ? 1 : 0);
            return sendSignalInfo;
        }

        SignalSaveInfo signalSaveInfo = signalSaveInfoMap.get(signal.modelId);
        if (null == signalSaveInfo) {
            return null;
        }
        if (signalSaveInfo.saveType == SAVETYPE_DB) {
            SignalData signalData = new SignalData();
            if (signalDBOprator.getOneSignalData(signal.modelId, signal.keyType, signalData)) {
                SendSignalInfo sendSignalInfo = new SendSignalInfo();
                sendSignalInfo.signalType = signalSaveInfo.signalType;
                sendSignalInfo.signalData = signalData.getData();
                return sendSignalInfo;
            }
        } else {
            SendSignalInfo sendSignalInfo = new SendSignalInfo();
            sendSignalInfo.signalType = signalSaveInfo.signalType;

            if (!signal.simpleSignal) {
                if (null == airKeysInfo) {
                    airKeysInfo = airConStatusManager.getAirConditionStatus(signal.roomId, signal.modelId);
                    if (null == airKeysInfo) {
                        return null;
                    }
                    if(!airKeysInfo.setKeyType(signal.keyType, signal.keyValue)) {
                        return null;
                    }
                }

                byte[] keyCodes = IRUtil.getSignalData(context.getFilesDir().getPath() + "/"
                        + IRUtil.getFolderByModelType(signal.modelType) + "/"
                        + signal.modelId + ".txt", airKeysInfo, signalSaveInfo.keySequence);
                if (null == keyCodes) {
                    return null;
                }
                sendSignalInfo.signalData = makeSendSignal(Integer.valueOf(signal.modelId), keyCodes);

                //String strTest = "33,04,00,00,24,00,26,81,cc,02,64,81,ce,06,b6,c1,10,dd,c2,00,11,70,c3,00,30,4d,b2,f8,07,1b,e4,c2,00,14,a2,c1,10,da,c2,00,11,74,c3,00,30,4d,b2,f8,07,1b,e4,00,";
                //sendSignalInfo.signalData = IRUtil.stringToBytes(strTest);
                airConStatusManager.changeAirCondition(airKeysInfo);
            } else {
                int index = IRUtil.getSignalIndex(signal.modelType, signal.keyType);
                byte[] keyCodes = IRUtil.getSignalData(context.getFilesDir().getPath() + "/"
                        + IRUtil.getFolderByModelType(signal.modelType) + "/"
                        + signal.modelId + ".txt", index);
                sendSignalInfo.signalData = makeSendSignal(Integer.valueOf(signal.modelId), keyCodes);
            }
            return sendSignalInfo;
        }
        return null;
    }

    private byte[] makeSendSignal(int fid, byte[] keyCode) {
        if (keyCode == null) {
            return null;
        }
        Map<Integer, IrDataFormate> allMaches = signalDBOprator.getAllMaches();
        IrDataFormate irDataFormate = allMaches.get(fid);
        byte[] formatBytes = IRUtil.stringToBytes(irDataFormate.formatString);
        String[] c3rvs = irDataFormate.c3rv.split("\\|");

        int codeBegin = 0;
        for (int i=0; i<c3rvs.length; ++i) {
            if (c3rvs[i].length() <= 0) {
                continue;
            }
            String[] replace = c3rvs[i].split("-");
            if (replace.length == 2) {
                int begin = Integer.valueOf(replace[0]);
                int length = Integer.valueOf(replace[1]);
                if (begin+length > formatBytes.length) {
                    return null;
                }
                System.arraycopy(keyCode, codeBegin, formatBytes, begin, length);
                codeBegin += length;
            }
        }

        return formatBytes;
    }

    private boolean sendSignalData(int roomID, SendSignalInfo sendSignalInfo) {
        SensorDevInfo sensorDevInfo = SystemSetting.getInstance().getCtrlDeviceInfo().getSensorDevInfoByRoomId(roomID, SensorTypeDef.SENSOR_DEV_MULTI);
        if (null == sensorDevInfo) {
            Logger.w("Get send sensor failed!!" + roomID);
            return false;
        }
        return CmdInterface.instance().controlDevice(sensorDevInfo.getMacAddress(), sendSignalInfo.signalType, sendSignalInfo.signalData);
    }

    private void reportToCloud(int roomType, int roomID, int deviceID, int deviceType, short keyType) {
        int controlID = SystemSetting.getInstance().getCtrlDeviceInfo().getDeviceID();
        CmdInterface.instance().uploadRemoteControlOperation(controlID, roomType, roomID, deviceID, deviceType, keyType);
    }

    private String getIRDataUrl(int applianceType, String modelID) {
        return CmdInterface.instance().getIRDataUrl(applianceType, modelID);
    }

    private void getIRFile(DownloadInfo downloadInfo) {
        downloader.addDownload(downloadInfo);
    }

    private boolean matchModel(byte[] signalData, final int modelType) {
        if (signalData[0] == 0) {
            informUI(SIGNAL_ACTION_MATCH, "");
            return  false;
        }
        return CmdInterface.instance().recongnizeIRCode(0, modelType, signalData,
                new ICallBackHandler(){
                    public void handleCallBack(short cmd, JSONObject json){
                        if (cmd != CmdDef.CMD_RECOGNIZE_INFRARED_CODE_ACK) {
                            return;
                        }
                        try {
                            if (json.has("errorCode")) {
                                int nRet = json.getInt("errorCode");
                                if (nRet != 0) {
                                    Logger.i("handleGetIRDataUrlAck failed " + nRet);
                                    return;
                                }
                            }

                            String url = json.optString("url");
                            int fid = json.optInt("fid");
                            String modelID = Integer.toString(fid);
                            int diff = json.optInt("bitDifference");
                            if (diff <= LogicDef.IRMATCH_DIFF_BITS) {
                                informUI(SIGNAL_ACTION_MATCH, modelID);
                                if (signalSaveInfoMap.containsKey(modelID)) {
                                    informUI(SIGNAL_ACTION_DOWNLOAD, modelID, true);
                                } else {
                                    downLoadIRFile(url, modelID);
                                }
                            } else {
                                informUI(SIGNAL_ACTION_MATCH, "");
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
    }

    private void downLoadIRFile(String url, String modelID) {
        if (null != url) {
            int firstOfSplit = url.indexOf("/");
            String[] urlSplit = url.split("/");
            if (urlSplit.length < 3) {
                return;
            }

            DownloadInfo downloadInfo = new DownloadInfo();
            downloadInfo.url = url.substring(0, firstOfSplit);
            downloadInfo.modelID = modelID;
            downloadInfo.modelType = IRUtil.getModelTypeByFolder(urlSplit[urlSplit.length-3]);
            downloadInfo.filePath = url.substring(firstOfSplit, url.length());
            downloadInfo.saveDir = context.getFilesDir().getPath() + "/" + urlSplit[urlSplit.length-3] + "/" + urlSplit[urlSplit.length-1];
            downloadInfo.handler = this;

            getIRFile(downloadInfo);
        }
    }

    private void saveIRFile(String modelID, int modelType) {
        MatchModelInfo modelInfo = signalDBOprator.getModel(Integer.valueOf(modelID));
        SignalSaveInfo signalSaveInfo = new SignalSaveInfo(modelID, (short) SensorTypeDef.SENSOR_INFRARED_SEND, SAVETYPE_FILE, modelInfo.getKeySequency(), modelType);
        signalSaveInfoMap.put(modelID, signalSaveInfo);
        signalDBOprator.addOneSignalSaveInfo(signalSaveInfo);
    }

    private void informUI(String action, String modelID) {
        Intent intent = new Intent();
        intent.setAction(action);
        intent.putExtra("signalFid", modelID);
        context.sendBroadcast(intent);
    }

    private void informUI(String action, String modelID, boolean params) {
        Intent intent = new Intent();
        intent.setAction(action);
        intent.putExtra("signal", params);
        intent.putExtra("signalFid", modelID);
        context.sendBroadcast(intent);
    }

    private void informUI(String action, int result) {
        Intent intent = new Intent();
        intent.setAction(action);
        intent.putExtra("result",result);
        context.sendBroadcast(intent);
    }


}
