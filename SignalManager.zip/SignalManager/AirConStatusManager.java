package LogicLayer.SignalManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import LogicLayer.SignalManager.IrDB.AirKeysInfo;
import LogicLayer.SignalManager.IrDB.SignalDBOprator;

/**
 * Created by RyanLee on 2015/4/27.
 */
public class AirConStatusManager {
    SignalDBOprator signalDBOprator;
    Map<Integer, ArrayList<AirKeysInfo>> airKeysInfos = new HashMap<Integer, ArrayList<AirKeysInfo>>();

    public void init(SignalDBOprator signalDBOprator) {
        this.signalDBOprator = signalDBOprator;
        if (null != signalDBOprator) {
            airKeysInfos = signalDBOprator.getAllAirKeysInfos();
        }
    }
    public void addAirCondition(AirKeysInfo airKeysInfo) {
        ArrayList<AirKeysInfo> mapInfos = airKeysInfos.get(airKeysInfo.roomID);
        if (null != mapInfos) {
            for (AirKeysInfo listInfo:mapInfos) {
                if (listInfo.modelID.equals(airKeysInfo.modelID)) {
                    mapInfos.remove(listInfo);
                    mapInfos.add(airKeysInfo);
                    break;
                }
            }
        }
        else {
            mapInfos = new ArrayList<AirKeysInfo>();
            mapInfos.add(airKeysInfo);
        }
        airKeysInfos.put(airKeysInfo.roomID, mapInfos);
        if (null != signalDBOprator) {
            signalDBOprator.addAirKeysInfo(airKeysInfo);
        }
    }

    public void removeAirCondition(int roomID, String modelID) {
        ArrayList<AirKeysInfo> mapInfos = airKeysInfos.get(roomID);
        if (null != mapInfos) {
            for (AirKeysInfo listInfo:mapInfos) {
                if (listInfo.modelID.equals(modelID)) {
                    mapInfos.remove(listInfo);
                    break;
                }
            }

            if (mapInfos.size() == 0) {
                airKeysInfos.remove(roomID);
            }
        }
        if (null != signalDBOprator) {
            signalDBOprator.removeAirKeysInfo(roomID, modelID);
        }
    }

    public void changeAirCondition(AirKeysInfo airKeysInfo) {
        ArrayList<AirKeysInfo> mapInfos = airKeysInfos.get(airKeysInfo.roomID);
        if (null != mapInfos) {
            for (AirKeysInfo listInfo:mapInfos) {
                if (null == listInfo.modelID) {
                    continue;
                }
                if (listInfo.modelID.equals(airKeysInfo.modelID)) {
                    mapInfos.remove(listInfo);
                    mapInfos.add(airKeysInfo);
                    break;
                }
            }
        }

        if (null != signalDBOprator) {
            signalDBOprator.changeAirKeysInfo(airKeysInfo);
        }
    }

    public AirKeysInfo getAirConditionStatus(int roomID, String modelID) {
        AirKeysInfo airKeysInfo = null;
        ArrayList<AirKeysInfo> mapInfos = airKeysInfos.get(roomID);
        if (null != mapInfos) {
            for (AirKeysInfo listInfo:mapInfos) {
                if (null == listInfo.modelID) {
                    continue;
                }
                if (listInfo.modelID.equals(modelID)) {
                    airKeysInfo = listInfo;
                    break;
                }
            }
        }
        return airKeysInfo;
    }

}
