package LogicLayer.SignalManager;

import Communication.Util.BytesUtil;

/**
 * Created by RyanLee on 2015/4/1.
 */
public class IRHead {
    static final int IRHEAD_LENGTH = CommomHead.HEAD_LENGTH + 20;
    public CommomHead commomHead;
    public byte	    encodeFormate;
    public short	headHLvLeng;
    public short	headLLvLeng;
    public short	binary0HLvLen;
    public short	binary0LLvLen;
    public short	binary1HLvLen;
    public short	binary1LLvLen;
    public byte	    headSize;
    public short	blankTime1;
    public short	blankTime2;
    public short	blankTime3;

    IRHead(byte[] bytes, int pos) {
        int nPos = pos;
        commomHead = new CommomHead(bytes, nPos);
        nPos += CommomHead.HEAD_LENGTH;
        encodeFormate = bytes[nPos];
        nPos ++;
        headHLvLeng = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        headLLvLeng = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        binary0HLvLen = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        binary0LLvLen = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        binary1HLvLen = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        binary1LLvLen = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        headSize = bytes[nPos];
        nPos ++;
        blankTime1 = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        blankTime2 = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        blankTime3 = BytesUtil.getShort(bytes, nPos);
    }

    byte[] getBytes() {
        byte[] bytes = new byte[IRHEAD_LENGTH];
        int nPos = 0;
        System.arraycopy(bytes, nPos, commomHead.getBytes(), 0, CommomHead.HEAD_LENGTH);
        nPos += CommomHead.HEAD_LENGTH;
        bytes[nPos] = encodeFormate;
        nPos ++;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(headHLvLeng), 0, 2);
        nPos += 2;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(headLLvLeng), 0, 2);
        nPos += 2;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(binary0HLvLen), 0, 2);
        nPos += 2;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(binary0LLvLen), 0, 2);
        nPos += 2;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(binary1HLvLen), 0, 2);
        nPos += 2;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(binary1LLvLen), 0, 2);
        nPos += 2;
        bytes[nPos] = headSize;
        nPos ++;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(blankTime1), 0, 2);
        nPos += 2;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(blankTime2), 0, 2);
        nPos += 2;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(blankTime3), 0, 2);

        return bytes;
    }
}
