package LogicLayer.SignalManager;

import Communication.Util.BytesUtil;

/**
 * Created by RyanLee on 2015/4/1.
 */
public class RFHead {
    static final int RFHEAD_LENGTH = CommomHead.HEAD_LENGTH + 25;
    public CommomHead commomHead;
    public byte	    encodeFormate;
    public short	headHLvLeng;
    public short	headLLvLeng;
    public byte	    headSize;
    public short	idleTime;
    public short	binary0HLvLen;
    public short	binary0LLvLen;
    public short	binary1HLvLen;
    public short	binary1LLvLen;
    public short	byteCount;
    public short	reserved;
    public short	endHLv;
    public short	endLLv;
    public byte	    dataLen;

    RFHead(byte[] bytes, int pos) {
        int nPos = pos;
        commomHead = new CommomHead(bytes, nPos);
        nPos += CommomHead.HEAD_LENGTH;
        encodeFormate = bytes[nPos];
        nPos++;
        headHLvLeng = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        headLLvLeng = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        headSize = bytes[nPos];
        nPos ++;
        idleTime = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        binary0HLvLen = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        binary0LLvLen = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        binary1HLvLen = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        binary1LLvLen = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        byteCount = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        reserved = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        endHLv = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        endLLv = BytesUtil.getShort(bytes, nPos);
        nPos += 2;
        dataLen = bytes[nPos];
    }

    byte[] getBytes() {
        byte[] bytes = new byte[RFHEAD_LENGTH];
        int nPos = 0;
        System.arraycopy(bytes, nPos, commomHead.getBytes(), 0, CommomHead.HEAD_LENGTH);
        nPos += CommomHead.HEAD_LENGTH;
        bytes[nPos] = encodeFormate;
        nPos ++;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(headHLvLeng), 0, 2);
        nPos += 2;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(headLLvLeng), 0, 2);
        nPos += 2;
        bytes[nPos] = headSize;
        nPos ++;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(idleTime), 0, 2);
        nPos += 2;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(binary0HLvLen), 0, 2);
        nPos += 2;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(binary0LLvLen), 0, 2);
        nPos += 2;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(binary1HLvLen), 0, 2);
        nPos += 2;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(binary1LLvLen), 0, 2);
        nPos += 2;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(byteCount), 0, 2);
        nPos += 2;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(reserved), 0, 2);
        nPos += 2;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(endHLv), 0, 2);
        nPos += 2;
        System.arraycopy(bytes, nPos, BytesUtil.getBytes(endLLv), 0, 2);
        nPos += 2;
        bytes[nPos] = dataLen;

        return bytes;
    }
}
